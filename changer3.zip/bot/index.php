<?php

include('logic.php');

# Принимаем запрос
$data = json_decode(file_get_contents('php://input'), TRUE);


if ($data['callback_query'] != null) {
    callback_querys($data);
} elseif ($data['message'] != null) {
    messages($data);
}


function callback_querys($data)
{
    $method = 'sendMessage';
    $call = $data['callback_query']['data'];
    if ($call == 'apply') {

        // update_apply($data['callback_query']['message']['chat']['id']);
        $method = 'editMessageText';
        $send_data = [
            'text' => "Подача заявки (1/3)\n\n🔗 Ресурс: Не указан\n⚙️ Опыт: Не указан\n\n📌 Расскажи откуда о нас узнал (реклама/знакомые/форум и т.д.)\n\n🔽 Введи ресурс 🔽",
            'message_id' => $data['callback_query']['message']['message_id'],
            'reply_markup' => ['inline_keyboard' => [[['text' => '🚫 Отмена', 'callback_data' => 'cancel_apply']]]]
        ];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
        update_step(1, $data['callback_query']['message']['chat']['id'], $res['result']['message_id']);
    } elseif ($call == 'cancel_apply') {
        $method = 'editMessageText';
        $send_data = [
            'text' => "⚠️ Внимание ⚠️\n\n🔔Функционал бота доступен только пользователям, которые состоят в тиме. Подай заявку, чтобы вступить в тиму и получить доступ к функционалу проекта.\n\n🔽 Подать заявку 🔽",
            'message_id' => $data['callback_query']['message']['message_id'],
            'reply_markup' => ['inline_keyboard' => [[['text' => '📍 Подать заявку', 'callback_data' => 'apply']]]]
        ];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
        update_step(0, $data['callback_query']['message']['chat']['id'], 0);
    } elseif ($call == 'stepp_aplly_one') {
        $user = check_user($data['callback_query']['message']['chat']['id'], $data['callback_query']['message']['chat']['username'], $data['callback_query']['message']['chat']['first_name']);
        $method = 'editMessageText';
        $send_data = [
            'text' => "Подача заявки (2/3)\n\n🔗 Ресурс: {$user['resource']}\n⚙️ Опыт: Не указан\n\n📌 Расскажи об опыте работы в данной сфере\n\n🔽 Введи опыт 🔽",
            'message_id' => $data['callback_query']['message']['message_id'],
            'reply_markup' => ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'apply']]]]
        ];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
        update_step(2, $data['callback_query']['message']['chat']['id'], $res['result']['message_id']);
    } elseif ($call == 'apply_done') {
        $user = check_user($data['callback_query']['message']['chat']['id'], $data['callback_query']['message']['chat']['username'], $data['callback_query']['message']['chat']['first_name']);
        //user
        $method = 'editMessageText';
        $send_data = [
            'text' => "✅ Заявка успешно подана\n\n🆔 Уникальный ID: {$user['key']}\n🗞 Тип заявки: Вступление\n⚙️ Статус: 🟡 В обработке\n\n🔽 Проверить статус 🔽",
            'message_id' => $data['callback_query']['message']['message_id'],
            'reply_markup' => ['inline_keyboard' => [[['text' => '🔄 Проверить заявку', 'callback_data' => 'refresh_order']]]]
        ];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
        update_step(0, $data['callback_query']['message']['chat']['id'], $user['msg']);
        //admin
        $method = 'sendMessage';
        $send_data = [
            'text' => "✅ Новая заявка\n\n🆔 Уникальный ID: {$user['key']}\n🧑‍💻 Username: @{$data['callback_query']['message']['chat']['username']}\n🔗 Ресурс: {$user['resource']}\n⚙️ Опыт: {$user['experience']}",
            'reply_markup' => ['inline_keyboard' => [[['text' => 'Подтвердить', 'callback_data' => "add_work:{$data['callback_query']['message']['chat']['id']}"]], [['text' => 'Отменить', 'callback_data' => "cancel_work:{$data['callback_query']['message']['chat']['id']}"]]]]
        ];
        $send_data['chat_id'] = admin_chat;
        $res = sendTelegram($method, $send_data);
    } elseif ($call == 'refresh_order') {
        $worker = get_user_id($data['callback_query']['message']['chat']['id']);
        if ($worker['apply'] == true) {
            $method = 'editMessageText';
            $send_data = [
                'text' => "✅ Заявка успешно подана\n\n🆔 Уникальный ID: {$worker['key']}\n🗞 Тип заявки: Вступление\n⚙️ Статус: 🟢 Принято",
                'message_id' => $worker['msg']
            ];
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
            $send_data = [
                'text' => "⚠️ Заявка рассмотрена ⚠️\n\n📍 Твоя заявка на вступление была одобрена. Ты был добавлен в тиму и теперь тебе доступен весь пользовательский функционал бота. 🥳\n\n🔽 Перейти в меню 🔽",
                'reply_markup' => ['inline_keyboard' => [[['text' => 'Меню', 'callback_data' => 'menu']]]]
            ];
            $method = 'sendMessage';
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        } elseif ($worker['cancel'] == true) {
            $method = 'editMessageText';
            $send_data = [
                'text' => "✅ Заявка успешно подана\n\n🆔 Уникальный ID: {$worker['key']}\n🗞 Тип заявки: Вступление\n⚙️ Статус: 🔴 Отменен",
                'message_id' => $worker['msg']
            ];
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
            $send_data = [
                'text' => "⚠️ Заявка рассмотрена ⚠️\n\n📍 Твоя заявка на вступление была отклоненна."
            ];
            $method = 'sendMessage';
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        }
    } elseif ($call == 'menu') {
        $user = get_user_id($data['callback_query']['message']['chat']['id']);
        if ($user['address'] == 'noned') {
            $method = 'editMessageText';
            $send_data = select_coin_start();
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        } else {
            $method = 'editMessageText';
            $send_data = get_menu_worker($data['callback_query']['message']['chat']['id']);
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        }
    } elseif ($call == 'site') {
        $method = 'editMessageText';
        $send_data = get_site();
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    } elseif ($call == 'ref_worker') {
        $method = 'editMessageText';
        $send_data = get_ref_worker($data['callback_query']['message']['chat']['id']);
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    }

    elseif($call == 'order_payment'){
        $method = 'editMessageText';
        $send_data = get_order_payments($data['callback_query']['message']['chat']['id']);
        if($send_data == false){
            $method = 'answerCallbackQuery';
            $send_data['callback_query_id'] = $data['callback_query']['id'];
            $send_data['show_alert'] = true;
            $send_data['text'] = 'Баланс должен быть больше 50$';
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        }else{
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        }
        
    }

    // elseif($call == 'finance'){
    //     $method = 'editMessageText';
    //     $send_data = get_finance($data['callback_query']['message']['chat']['id']);
    //     $send_data['message_id'] = $data['callback_query']['message']['message_id'];
    //     $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
    //     $res = sendTelegram($method, $send_data);
    // }

    elseif ($call == 'finance') {
        $method = 'editMessageText';
        $send_data = get_finance($data['callback_query']['message']['chat']['id']);
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    } elseif ($call == 'changes') {
        $method = 'editMessageText';
        $send_data = get_changes($data['callback_query']['message']['chat']['id']);
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    } elseif ($call == 'changes_status') {
        $method = 'editMessageText';
        $send_data = get_chages_status();
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    } elseif ($call == 'information') {
        $method = 'editMessageText';
        $send_data = get_information();
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    } elseif ($call == 'manual') {
        $method = 'editMessageText';
        $send_data = get_manul();
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    } elseif ($call == 'chats') {
        $method = 'editMessageText';
        $send_data = get_chats();
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    }elseif ($call == 'change_address_start') {
        $method = 'editMessageText';
        $send_data = select_coin_start();
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
        update_step(0, $data['callback_query']['message']['chat']['id'], 0);
    } elseif ($call == 'change_address') {
        $method = 'editMessageText';
        $send_data = select_coin();
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
        update_step(0, $data['callback_query']['message']['chat']['id'], 0);
    }  elseif(stristr($call, 'history_payment')){
        $type = explode(":",$call)[1];
        $num = explode(":", $call)[2];
        $send_data = get_history_payments($data['callback_query']['message']['chat']['id'], $type, $num);
        if($send_data == false){
            $method = 'answerCallbackQuery';
            $send_data['callback_query_id'] = $data['callback_query']['id'];
            $send_data['show_alert'] = true;
            $send_data['text'] = 'У вас нет истории выплаты';
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        }else{
            $method = 'editMessageText';
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        }
    } 
    elseif(stristr($call, 'payment_d')){
        $id_user = explode(":",$call)[1];
        $summ_usd = explode(":", $call)[2];
        $send_data = done_payment_channel($id_user, $summ_usd);
        $method = 'editMessageText';
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);

    } elseif(stristr($call, 'payments_c')){
        $id_user = explode(":",$call)[1];
        $summ_usd = explode(":", $call)[2];
        $send_data = cancel_payment_channel($id_user, $summ_usd);
        $method = 'editMessageText';
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    } elseif (stristr($call, 'select_coin_start')) {
        $coin = explode(":", $call)[1];
        $method = 'editMessageText';
        $send_data = input_address_start($coin);
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
        update_step(13, $data['callback_query']['message']['chat']['id'], $res['result']['message_id']);
        update_change_sign($coin, $data['callback_query']['message']['chat']['id']);
    } elseif (stristr($call, 'select_coin')) {
        $coin = explode(":", $call)[1];
        //$user = get_user_id($data['callback_query']['message']['chat']['id']);
        $method = 'editMessageText';
        $send_data = input_address($coin);
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
        update_step(4, $data['callback_query']['message']['chat']['id'], $res['result']['message_id']);
        update_change_sign($coin, $data['callback_query']['message']['chat']['id']);
    } elseif (stristr($call, 'add_work')) {
        $id = explode(":", $call)[1];
        update_apply($id, true);
        $worker = get_user_id($id);
        $method = 'editMessageText';
        $send_data = [
            'text' => "✅ Заявка успешно принята\n\n🆔 Уникальный ID: {$worker['key']}\n🧑‍💻 Username: @{$worker['username']}\n🔗 Ресурс: {$worker['resource']}\n⚙️ Опыт: {$worker['experience']}",
            'message_id' => $data['callback_query']['message']['message_id'],
        ];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    } elseif (stristr($call, 'cancel_work')) {
        $id = explode(":", $call)[1];
        update_cancle($id);
        $worker = get_user_id($id);
        $method = 'editMessageText';
        $send_data = [
            'text' => "❌ Заявка отклонена\n\n🆔 Уникальный ID: {$worker['key']}\n🧑‍💻 Username: @{$worker['username']}\n🔗 Ресурс: {$worker['resource']}\n⚙️ Опыт: {$worker['experience']}",
            'message_id' => $data['callback_query']['message']['message_id'],
        ];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $res = sendTelegram($method, $send_data);
    } elseif (strstr($call, 'statistic_exchange')) {
        $type = explode(":", $call)[1];

        $send_data = get_exchange_exchange($data['callback_query']['message']['chat']['id'], $type);
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $method = 'editMessageText';
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $res = sendTelegram($method, $send_data);
    } elseif (strstr($call, 'exchangeid')) {
        $id_exchange = explode(":", $call)[1];
        $send_data = create_statistic_exchange($id_exchange);
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        $method = 'editMessageText';
        $send_data['message_id'] = $data['callback_query']['message']['message_id'];
        $res = sendTelegram($method, $send_data);
    } elseif (stristr($call, 'exchange')) {
        $func = explode(":", $call)[1];
        $type = explode(":", $call)[2];
        $id_exchange = explode(":", $call)[3];
        $order = get_exchange_id($id_exchange);
        $coin = get_coin_by_id($order['id_coin_from']);
        $worker = get_user_by_key($order['key']);
        $method = 'editMessageText';
        $send_data = [
            'message_id' => $data['callback_query']['message']['message_id'],
        ];
        $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
        if ($type == 'crypto') {
            if ($func == 'done') {
                exchange_solution_admin($order, 'done');
                $send_data['text'] = "⚠️ Вы подтвердили ⚠️\n\n🔔 IP: {$order['ip']}\n🆔 Уникальный ID: {$order['id']}\n🦣 Почта мамонта: {$order['mail']}\n💸 Сумма: {$order['summ_from']} {$coin_from['sign']}\n😏 Получает: {$order['summ_to']} {$coin_to['sign']}\n💼 Адрес: {$order['address']}\n\n";
            } elseif ($func == 'cancel') {
                exchange_solution_admin($order, 'cancel');
                $send_data['text'] = "⚠️ Вы отменили ⚠️\n\n🔔 IP: {$order['ip']}\n🆔 Уникальный ID: {$order['id']}\n🦣 Почта мамонта: {$order['mail']}\n💸 Сумма: {$order['summ_from']} {$coin_from['sign']}\n😏 Получает: {$order['summ_to']} {$coin_to['sign']}\n💼 Адрес: {$order['address']}\n\n";
            }
            $res = sendTelegram($method, $send_data);
        } elseif ($type == 'card') {
            if ($func == 'done') {
                exchange_solution_admin($order, 'done');
                $send_data['text'] = "⚠️ Вы подтвердили ⚠️\n\n🔔 IP: {$order['ip']}\n🆔 Уникальный ID: {$order['id']}\n🦣 Почта мамонта: {$order['mail']}\n💸 Сумма: {$order['summ_from']} {$coin_from['sign']}\n😏 Получает: {$order['summ_to']} {$coin_to['sign']}\n💼 Адрес: {$order['address']}\n\n";
            } elseif ($func == 'cancel') {
                exchange_solution_admin($order, 'cancel');
                $send_data['text'] = "⚠️ Вы отменили ⚠️\n\n🔔 IP: {$order['ip']}\n🆔 Уникальный ID: {$order['id']}\n🦣 Почта мамонта: {$order['mail']}\n💸 Сумма: {$order['summ_from']} {$coin_from['sign']}\n😏 Получает: {$order['summ_to']} {$coin_to['sign']}\n💼 Адрес: {$order['address']}\n\n";
            } //else {
            //     exchange_solution_admin($type, $order, 'eror');
            //     $send_data['text'] = "⚠️ Вы отменили перевод для обих сторон ⚠️\n\n🔔IP: {$order['ip']}\n🆔 Уникальный ID: {$order['id']}\n🦣 Мамонт: {$order['mail']}\n💸 Сумма: {$order['summ_from']} {$coin['sign']}\n💼 Адрес: {$order['address_to']}\n\n";
            // }
            $res = sendTelegram($method, $send_data);
        }
    elseif(stristr($call, 'block_exchange')){
        $id = explode(":", $call)[1];
        $order = get_exchange_id($id);
        add_ip_block($order['ip']);
        $method = 'editMessageText';
        $coin_from = get_coin_by_id($order['id_coin_from']);
        $coin_to = get_coin_by_id($order['id_coin_to']);
        $worker = get_user_by_key($order['key']);
        $text = "⚠️ Оплачено ⚠️\n\n🔔 IP: {$order['ip']}\n🆔 Уникальный ID: {$order['id']}\n🦣 Почта мамонта: {$order['mail']}\n💸 Сумма: {$order['summ_from']} {$coin_from['sign']}\n😏 Получает: {$order['summ_to']} {$coin_to['sign']}\n💼 Адрес: {$order['address']}\n\n";
        if ($worker != null) {
            $text .= "Айди воркера: {$worker['id']}\nЛинк воркера: @{$worker['username']}\n\n🔽 Что делаем? 🔽";
        } else {
            $text .= "🔽 Что делаем? 🔽";
        }
        $send_data = [
            'text' => $text,
            'message_id' => $data['callback_query']['message']['message_id'],
            'reply_markup' => ['inline_keyboard' => [[['text' => 'Подтвердить', 'callback_data' => "exchange:done:{$coin['type']}:{$order['id']}"],['text' => 'Отменить', 'callback_data' => "exchange:cancel:{$coin['type']}:{$order['id']}"]],[['text' => 'Ошибка', 'callback_data' => "exchange:eror:{$coin['type']}:{$order['id']}"], ['text' => 'Разблокировать', 'callback_data' => "unlock_exchange:{$order['id']}"]]]]
        ];
        $send_data['chat_id'] = admin_chat;
        $res = sendTelegram($method, $send_data);

    }elseif(stristr($call, 'unlock_exchange')){
        $id = explode(":", $call)[1];
        $order = get_exchange_id($id);
        delete_block_ip($order['ip']);
        $method = 'editMessageText';
        $coin = get_coin_by_id($order['id_coin_from']);
        $worker = get_user_by_key($order['key']);
        $text = "⚠️ Оплачено ⚠️\n\n🔔IP: {$order['ip']}\n🆔 Уникальный ID: {$order['id']}\n🦣 Мамонт: {$order['mail']}\n💸 Сумма: {$order['summ_from']} {$coin['sign']}\n💼 Адрес: {$order['address_to']}\n\n";
        if($worker != null){
            $text .= "Воркер\n\nid:{$worker['id']}\nFirst name: {$worker['first_name']}\nUsername: @{$worker['username']}\n\n🔽 Что деалем ? 🔽";
        }else{
            $text .= "🔽 Что делаем? 🔽";
        }
        $send_data = [
            'text' => $text,
            'message_id' => $data['callback_query']['message']['message_id'],
            'reply_markup' => ['inline_keyboard' => [[['text' => 'Подтвердить', 'callback_data' => "exchange:done:{$coin['type']}:{$order['id']}"],['text' => 'Отменить', 'callback_data' => "exchange:cancel:{$coin['type']}:{$order['id']}"]],[['text' => 'Ошибка', 'callback_data' => "exchange:eror:{$coin['type']}:{$order['id']}"], ['text' => 'Заблокировать', 'callback_data' => "block_exchange:{$order['id']}"]]]]
        ];
        $send_data['chat_id'] = admin_chat;
        $res = sendTelegram($method, $send_data);
    }
    } elseif (stristr($call, 'admin')) {
        $func = explode(":", $call)[1];
        if ($func == 'site') {
            $method = 'editMessageText';
            $send_data = get_admin_site();
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
            update_step(0, $data['message']['chat']['id'], 0);
        } elseif ($func == 'admin') {
            $method = 'editMessageText';
            $send_data = get_admin_();
            $res = sendTelegram($method, $send_data);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
        } elseif ($func == 'block_ip_country') {
            $method = 'editMessageText';
            $send_data = block_ip_country();
            $res = sendTelegram($method, $send_data);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
        } elseif ($func == 'country_block') {
            change_block_country_(explode(":", $call)[2]);
            $method = 'editMessageText';
            $send_data = block_ip_country();
            $res = sendTelegram($method, $send_data);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
        } elseif ($func == 'block_ip') {
            $method = 'editMessageText';
            $send_data = block_ip_user();
            $res = sendTelegram($method, $send_data);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
            update_step(12, $data['callback_query']['message']['chat']['id'], $res['result']['message_id']);
        } elseif ($func == 'set_addres_') {
            $method = 'editMessageText';
            $send_data = [
                'text' => 'Введите новый адрес для смены',
                'reply_markup' => ['inline_keyboard' => [[['text' => '❌ Отменить', 'callback_data' => 'admin:address']]]]
            ];
            $res = sendTelegram($method, $send_data);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
            update_step(10, $data['callback_query']['message']['chat']['id'], $res['result']['message_id']);
        } elseif ($func == 'set_procent_') {
            $method = 'editMessageText';
            $send_data = [
                'text' => 'Введите новый процент для смены',
                'reply_markup' => ['inline_keyboard' => [[['text' => '❌ Отменить', 'callback_data' => 'admin:procent']]]]
            ];
            $res = sendTelegram($method, $send_data);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
            update_step(11, $data['callback_query']['message']['chat']['id'], $res['result']['message_id']);
        } elseif ($func == 'address') {
            $method = 'editMessageText';
            $send_data = defolt_address();
            $res = sendTelegram($method, $send_data);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
            update_step(0, $data['callback_query']['message']['chat']['id'], 0);
        } elseif ($func == 'procent') {
            $method = 'editMessageText';
            $send_data = defolt_procent();
            $res = sendTelegram($method, $send_data);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
            update_step(0, $data['callback_query']['message']['chat']['id'], 0);
        } elseif ($func == 'dele') {
            delete_site(explode(":", $call)[2]);
            $method = 'editMessageText';
            $send_data = get_admin_site();
            $res = sendTelegram($method, $send_data);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
        } elseif ($func == 'add_site') {
            $method = 'editMessageText';
            $send_data = create_add_site();
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
            update_step(5, $data['callback_query']['message']['chat']['id'], $res['result']['message_id']);
        } elseif ($func == 'proc') {
            $method = 'editMessageText';
            $send_data = get_procent();
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
        } elseif ($func == 'first_proc' || $func == 'second_proc' || $func == 'three_proc') {
            $method = 'editMessageText';
            $send_data = get_table_proc($func);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
        } elseif ($func == 'change') {
            change_procent(explode(":", $call)[2], explode(":", $call)[3]);
            $method = 'editMessageText';
            $send_data = get_procent();
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
        } elseif ($func == 'settings_coins') {
            $method = 'editMessageText';
            $send_data = get_all_coins();
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
        } elseif ($func == 'coin') {
            $method = 'editMessageText';
            $send_data = create_setting_coin(explode(":", $call)[2]);
            $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
            $send_data['message_id'] = $data['callback_query']['message']['message_id'];
            $res = sendTelegram($method, $send_data);
            update_step(0, $data['callback_query']['message']['chat']['id'], 0);
        } elseif (strstr($func, 'setcoin')) {
            $settings = explode(":", $call)[2];
            if ($settings == 'from' || $settings == 'to') {
                set_from_to($settings, explode(":", $call)[3]);
                $method = 'editMessageText';
                $send_data = create_setting_coin(explode(":", $call)[3]);
                $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
                $send_data['message_id'] = $data['callback_query']['message']['message_id'];
                $res = sendTelegram($method, $send_data);
            } elseif ($settings == 'setmin') {
                $id = explode(":", $call)[3];
                $method = 'editMessageText';
                $send_data = [
                    'text' => 'Введите минимальную сумму',
                    'reply_markup' => ['inline_keyboard' => [[['text' => '❌ Отменить', 'callback_data' => "admin:coin:{$id}"]]]]
                ];
                $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
                $send_data['message_id'] = $data['callback_query']['message']['message_id'];
                $res = sendTelegram($method, $send_data);
                update_step(6, $data['callback_query']['message']['chat']['id'], $data['callback_query']['message']['message_id']);
                set_change_sign($id, $data['callback_query']['message']['chat']['id']);
            } elseif ($settings == 'setmax') {
                $id = explode(":", $call)[3];
                $method = 'editMessageText';
                $send_data = [
                    'text' => 'Введите максимальную сумму',
                    'reply_markup' => ['inline_keyboard' => [[['text' => '❌ Отменить', 'callback_data' => "admin:coin:{$id}"]]]]
                ];
                $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
                $send_data['message_id'] = $data['callback_query']['message']['message_id'];
                $res = sendTelegram($method, $send_data);
                update_step(7, $data['callback_query']['message']['chat']['id'], $data['callback_query']['message']['message_id']);
                set_change_sign($id, $data['callback_query']['message']['chat']['id']);
            } elseif ($settings == 'procent') {
                $id = explode(":", $call)[3];
                $method = 'editMessageText';
                $send_data = [
                    'text' => 'Введите процент на эту валюту(1.5 - 50%)',
                    'reply_markup' => ['inline_keyboard' => [[['text' => '❌ Отменить', 'callback_data' => "admin:coin:{$id}"]]]]
                ];
                $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
                $send_data['message_id'] = $data['callback_query']['message']['message_id'];
                $res = sendTelegram($method, $send_data);
                update_step(8, $data['callback_query']['message']['chat']['id'], $data['callback_query']['message']['message_id']);
                set_change_sign($id, $data['callback_query']['message']['chat']['id']);
            } elseif ($settings == 'address') {
                $id = explode(":", $call)[3];
                $method = 'editMessageText';
                $send_data = [
                    'text' => 'Введите адрес на который будут поступать средства этого банка',
                    'reply_markup' => ['inline_keyboard' => [[['text' => '❌ Отменить', 'callback_data' => "admin:coin:{$id}"]]]]
                ];
                $send_data['chat_id'] = $data['callback_query']['message']['chat']['id'];
                $send_data['message_id'] = $data['callback_query']['message']['message_id'];
                $res = sendTelegram($method, $send_data);
                update_step(9, $data['callback_query']['message']['chat']['id'], $data['callback_query']['message']['message_id']);
                set_change_sign($id, $data['callback_query']['message']['chat']['id']);
            }
        }
    }
}

function messages($data)
{
    $method = 'sendMessage';
    $msg = $data['message']['text'];
    if ($msg == '/start') {
        $user = check_user($data['message']['chat']['id'], $data['message']['chat']['username'], $data['message']['chat']['first_name']);
        if ($user['cancel'] == true) {
            $send_data = [
                'text' => 'Доступ закрыт'
            ];
            $send_data['chat_id'] = $data['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        } elseif ($user['apply'] == true) {
            if ($user['address'] == 'noned') {
                $method = 'sendMessage';
                $send_data = select_coin_start();
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $res = sendTelegram($method, $send_data);
            } else {
                $send_data = get_menu_worker($data['message']['chat']['id']);
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $res = sendTelegram($method, $send_data);
            }
        } else {
            $send_data = [
                'text' => "⚠️ Внимание ⚠️\n\n🔔Функционал бота доступен только пользователям, которые состоят в тиме. Подай заявку, чтобы вступить в тиму и получить доступ к функционалу проекта.\n\n🔽 Подать заявку 🔽\n\n",
                'reply_markup' => ['inline_keyboard' => [[['text' => '📍 Подать заявку', 'callback_data' => 'apply']]]]
            ];
            $send_data['chat_id'] = $data['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        }
    } elseif ($msg == '/admin') {
        if ($data['message']['chat']['id'] == admin) {
            $send_data = get_admin_();
            $send_data['chat_id'] = $data['message']['chat']['id'];
            $res = sendTelegram($method, $send_data);
        }
    } else {
        $user = check_user($data['message']['chat']['id'], $data['message']['chat']['username'], $data['message']['chat']['first_name']);
        if ($user['msg'] != 0) {
            if ($user['step_apply'] == 1) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $res = sendTelegram($method, $send_data);
                update_resource($data['message']['chat']['id'], $data['message']['text']);
                $method = 'editMessageText';
                $send_data = [
                    'text' => "Подача заявки (2/3)\n\n🔗 Ресурс: {$data['message']['text']}\n⚙️ Опыт: Не указан\n\n📌 Расскажи об опыте работы в данной сфере\n\n🔽 Введи опыт 🔽",
                    'message_id' => $user['msg'],
                    'reply_markup' => ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'apply']]]]
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $res = sendTelegram($method, $send_data);
                update_step(2, $data['message']['chat']['id'], $user['msg']);
            } elseif ($user['step_apply'] == 2) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $res = sendTelegram($method, $send_data);
                update_experience($data['message']['chat']['id'], $data['message']['text']);
                $method = 'editMessageText';
                $send_data = [
                    'text' => "Подача заявки (3/3)\n\n🔗 Ресурс: {$user['resource']}\n⚙️ Опыт: {$data['message']['text']}\n\n📌 Подтверди указанные данные, чтобы отправить заявку\n\n🔽 Подтверди данные 🔽",
                    'message_id' => $user['msg'],
                    'reply_markup' => ['inline_keyboard' => [[['text' => '✅ Подтвердить', 'callback_data' => 'apply_done']], [['text' => '↩️ Назад', 'callback_data' => 'stepp_aplly_one']]]]
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $res = sendTelegram($method, $send_data);
                update_step(3, $data['message']['chat']['id'], $user['msg']);
            } elseif ($user['step_apply'] == 4) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                update_address($data['message']['text'], $data['message']['chat']['id']);
                update_sign($user['change_sign'], $data['message']['chat']['id']);
                $res = sendTelegram($method, $send_data);
                $method = 'editMessageText';
                $send_data = get_finance($data['message']['chat']['id']);
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $send_data['message_id'] = $user['msg'];
                $res = sendTelegram($method, $send_data);
                update_step(0, $data['message']['chat']['id'], 0);
            } elseif ($user['step_apply'] == 5) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                add_site($data['message']['text']);
                $res = sendTelegram($method, $send_data);
                $method = 'editMessageText';
                $send_data = get_admin_site();
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $send_data['message_id'] = $user['msg'];
                $res = sendTelegram($method, $send_data);
                update_step(0, $data['message']['chat']['id'], 0);
            } elseif ($user['step_apply'] == 6) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                change_min($data['message']['text'], $user['change_sign']);
                $res = sendTelegram($method, $send_data);
                $method = 'editMessageText';
                $send_data = create_setting_coin($user['change_sign']);
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $send_data['message_id'] = $user['msg'];
                $res = sendTelegram($method, $send_data);
                update_step(0, $data['message']['chat']['id'], 0);
            } elseif ($user['step_apply'] == 7) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                change_max($data['message']['text'], $user['change_sign']);
                $res = sendTelegram($method, $send_data);
                $method = 'editMessageText';
                $send_data = create_setting_coin($user['change_sign']);
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $send_data['message_id'] = $user['msg'];
                $res = sendTelegram($method, $send_data);
                update_step(0, $data['message']['chat']['id'], 0);
            } elseif ($user['step_apply'] == 8) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                change_procent_coin($data['message']['text'], $user['change_sign']);
                $res = sendTelegram($method, $send_data);
                $method = 'editMessageText';
                $send_data = create_setting_coin($user['change_sign']);
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $send_data['message_id'] = $user['msg'];
                $res = sendTelegram($method, $send_data);
                update_step(0, $data['message']['chat']['id'], 0);
            } elseif ($user['step_apply'] == 9) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                change_address_coin($data['message']['text'], $user['change_sign']);
                $res = sendTelegram($method, $send_data);
                $method = 'editMessageText';
                $send_data = create_setting_coin($user['change_sign']);
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $send_data['message_id'] = $user['msg'];
                $res = sendTelegram($method, $send_data);
                update_step(0, $data['message']['chat']['id'], 0);
            } elseif ($user['step_apply'] == 11) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                change_procent('procent', $data['message']['text']);
                $res = sendTelegram($method, $send_data);
                $method = 'editMessageText';
                $send_data = defolt_procent();
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $send_data['message_id'] = $user['msg'];
                $res = sendTelegram($method, $send_data);
                update_step(0, $data['message']['chat']['id'], 0);
            } elseif ($user['step_apply'] == 10) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                change_procent('address', $data['message']['text']);
                $res = sendTelegram($method, $send_data);
                $method = 'editMessageText';
                $send_data = defolt_address();
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $send_data['message_id'] = $user['msg'];
                $res = sendTelegram($method, $send_data);
                update_step(0, $data['message']['chat']['id'], 0);
            } elseif ($user['step_apply'] == 12) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                add_ip_block_($data['message']['text']);
                $res = sendTelegram($method, $send_data);
                $method = 'editMessageText';
                $send_data = get_admin_();
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $send_data['message_id'] = $user['msg'];
                $res = sendTelegram($method, $send_data);
                update_step(0, $data['message']['chat']['id'], 0);
            } elseif ($user['step_apply'] == 13) {
                $method = 'deleteMessage';
                $send_data = [
                    'message_id' => $data['message']['message_id']
                ];
                $send_data['chat_id'] = $data['message']['chat']['id'];
                update_address($data['message']['text'], $data['message']['chat']['id']);
                update_sign($user['change_sign'], $data['message']['chat']['id']);
                $res = sendTelegram($method, $send_data);
                $method = 'editMessageText';
                $send_data = get_menu_worker($data['message']['chat']['id']);
                $send_data['chat_id'] = $data['message']['chat']['id'];
                $send_data['message_id'] = $user['msg'];
                $res = sendTelegram($method, $send_data);
                update_step(0, $data['message']['chat']['id'], 0);
            }
        }
    }
}




function sendTelegram($method, $data, $headers = [])
{
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_POST => 1,
        CURLOPT_HEADER => 0,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => 'https://api.telegram.org/bot' . TOKEN . '/' . $method,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => array_merge(array("Content-Type: application/json"), $headers)
    ]);

    $result = curl_exec($curl);
    curl_close($curl);
    return (json_decode($result, 1) ? json_decode($result, 1) : $result);
}
