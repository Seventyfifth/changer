<?php
include($_SERVER['DOCUMENT_ROOT'] . '/vender/database.php');

function check_user($id, $username, $first_name)
{
    $user = get_user($id);
    if ($user == null) {
        $key = generation_key();
        add_user($id, $username, $first_name, $key);
        $user = get_user($id);
        return $user;
    } else {
        return $user;
    }
}

function get_user_id($id)
{
    return get_user($id);
}

function update_apply($id, $bool)
{
    set_aplly($id, $bool);
}

function update_step($step, $id, $msg)
{
    set_step($step, $id, $msg);
}


function update_resource($id, $text)
{
    set_resource($id, $text);
}

function update_experience($id, $text)
{
    set_experience($id, $text);
}

function update_cancle($id)
{
    set_cancle($id);
}

function generation_key()
{
    $comb = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array();
    $combLen = strlen($comb) - 1;
    for ($i = 0; $i < 12; $i++) {
        $n = rand(0, $combLen);
        $pass[] = $comb[$n];
    }
    return implode($pass);
}

function get_menu_worker($id)
{
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);
    $user = get_user($id);
    $count_exchanges = get_exchanges_count_by_user($user['key']);
    $data = [
        'text' => "Главное меню:\n\n🆔 Уникальный ID: {$user['key']}\n⚜️ Баланс {$user['balance']}$\n💰 Заработано: {$user['balance_all']}$\n💱 Обменов: {$count_exchanges}\n🧮 Проценты: {$json_a['first_proc']} / {$json_a['second_proc']} / {$json_a['three_proc']}\n\n🔽 Выбери раздел 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => 'Сайты', 'callback_data' => 'site'], ['text' => 'Финансы', 'callback_data' => 'finance']], [['text' => 'Обмены', 'callback_data' => 'changes'], ['text' => 'Информация', 'callback_data' => 'information']]]]
    ];

    return $data;
}

function get_site(){
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);
    $site_text = "";
    $count_site = count($json_a['site']);
    for($i = 0; $i < count($json_a['site']); ++$i){
        $site_text .= "\n 🟢 ".$json_a['site'][$i];
    }
    $data = [
        'text' => "Сайты:\n\n📌 Всего сайтов: {$count_site}\n\n📍 Статусы сайтов:{$site_text}\n\n🔽 Выбери действие 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => 'Рефералки', 'callback_data' => 'ref_worker']], [['text' => '↩️ Назад', 'callback_data' => 'menu']]]]
    ];

    return $data;
}

function get_ref_worker($id)
{
    $user = get_user($id);
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);
    $site_text = "";
    for ($i = 0; $i < count($json_a['site']); ++$i) {
        $site_text .= "\n🔹 " . $json_a['site'][$i] . "\r?key={$user['key']}";
    }
    $data = [
        'text' => "Реферальные ссылки:\n{$site_text}",
        'reply_markup' => ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'site']]]]
    ];

    return $data;
}

// function get_finance($id){
//     $data = [
//         'text' => "Финансы\n\n💸 Всего заработано: $0\n💰 Баланс: $0\n\n📌 Доступные действия:\n 1️⃣ Просмотр платежей исходя из статуса\n 2️⃣ Просмотри запросов на вывод по статусам\n\n🔽 Выбери действие 🔽",
//         'reply_markup' => ['inline_keyboard' => [[['text' => 'Профиты', 'callback_data' => 'profite'], ['text' => 'Выводы', 'callback_data' => 'conclusion']], [['text' => '↩️ Назад', 'callback_data' => 'menu']]]]
//     ];

//     return $data;
// }

// function get_profite($id){
//     $data = [
//         'text' => "Профиты\n\nСтатусы\n🟡 В обработке: 0\n🟢 Принято: 0\n🔴 Отклонено: 0\n\n🔔 Для того, чтобы посмотреть профиты исходя из статуса, нажми соответствующую статусу кнопку.\n\n🔽 Выбери действие 🔽",
//         'reply_markup' => ['inline_keyboard' => [[['text' => '🟡  В обработке', 'callback_data' => 'profite_treatment']], [['text' => '🟢 Принято', 'callback_data' => 'profite_done'], ['text' => '🔴 Отклонено', 'callback_data' => 'profite_cancel']], [['text' => '↩️ Назад', 'callback_data' => 'menu']]]]
//     ];

//     return $data;
// }

function get_finance($id)
{
    $user = get_user($id);
    $data = [
        'text' => "📊 Финансы:\n\n👛 Ваш кошелек {$user['sign']} для выплат:\n{$user['address']}\n⚜️ Баланс: {$user['balance']}$\n\n🔽 Выбери действие 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => 'Сменить кошелек', 'callback_data' => 'change_address'], ['text' => 'История выплат', 'callback_data' => 'history_payment:next:0']], [['text' => '⚜️ Заказать выплату', 'callback_data' => 'order_payment']], [['text' => '↩️ Назад', 'callback_data' => 'menu']]]]
    ];

    return $data;
}

function get_chages_status()
{
    $data = [
        'text' => "Обмены:\n\n🔔 Для того, чтобы посмотреть обмены исходя из статуса, нажми соответствующую статусу кнопку.\n\n🔽 Выбери действие 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => '🟡  В обработке', 'callback_data' => 'statistic_exchange:check']], [['text' => '🟢 Принято', 'callback_data' => 'statistic_exchange:done'], ['text' => '🔴 Отклонено', 'callback_data' => 'statistic_exchange:cancel']], [['text' => '↩️ Назад', 'callback_data' => 'changes']]]]
    ];

    return $data;
}

function get_changes($id)
{
    $user = get_user($id);
    $all_exchange = get_exchanges_count_by_user($user['key']);
    $all_exchange_pay = get_user_exchanges_count_by_user_pay($user['key']);
    $data = [
        'text' => "Обмены:\n\n📍 Всего обменов: {$all_exchange}\n💰 Оплаченные обмены: {$all_exchange_pay}\n\n🔔 Ты можешь посмотреть, все обмены исходя из статуса,  нажав кнопку «Обмены».\n\n🔽 Выбери действие 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => 'Обмены', 'callback_data' => 'changes_status']], [['text' => '↩️ Назад', 'callback_data' => 'menu']]]]
    ];

    return $data;
}

function get_information()
{
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);
    $data = [
        'text' => "Информация:\n\nПроценты\n🔸 Общий: {$json_a['first_proc']}\n🔹 Возврат: {$json_a['second_proc']}\n🔸 Множитель: {$json_a['three_proc']}\n\n📌 Доступные действия:\n1️⃣ Просмотр мануалов по работе\n2️⃣ Просмотр списка ссылок на рабочие чаты\n3️⃣ Связь с поддержкой\n\n🔽 Выбери действие 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => 'Мануалы', 'callback_data' => 'manual'], ['text' => 'Чаты', 'callback_data' => 'chats']], [['text' => 'Поддержка', 'url' => 'https://t.me/reseller_changer']], [['text' => '↩️ Назад', 'callback_data' => 'menu']]]]
    ];

    return $data;
}

function get_manul()
{
    $data = [
        'text' => "Мануалы:\n\n📌 Мануал по скам обменнику (https://telegra.ph/Manual-po-skam-obmenniku-09-21)\n📌 Пример общения с лохом (https://telegra.ph/Primer-obshcheniya-s-lohom-09-21)\n📌 Пример общения | Профит 2к$ (https://telegra.ph/Primer-obshcheniyaprofit-2k-09-21)\n📌 Приватный мануал по арбитражу криптовалют (https://telegra.ph/Privatnyj-manual-po-arbitrazhu-kriptovalyut-09-21-2)\n\n🔽 Выбери действие 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'information']]]]
    ];

    return $data;
}

function get_chats()
{
    $chat_workers = work_chat_link;
    $payments_chanel = payment_chanel_link;
    $data = [
        'text' => "Чаты:\n\n📌 Рабочий чат ({$chat_workers})\n📌 Канал с выплатами ({$payments_chanel})\n\n🔽 Выбери действие 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'information']]]]
    ];

    return $data;
}

function select_coin()
{
    $data = [
        'text' => "Смена кошелька:\n\n🔽 Выбери монету 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => 'BTC', 'callback_data' => 'select_coin:BTC'], ['text' => 'TRC20', 'callback_data' => 'select_coin:USDT'], ['text' => 'TRX', 'callback_data' => 'select_coin:TRX']], [['text' => '↩️ Назад', 'callback_data' => 'finance']]]]
    ];

    return $data;
}


function select_coin_start()
{
    $data = [
        'text' => "Выбери монеты для выплат:\n\n🔽 Выбери монету 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => 'BTC', 'callback_data' => 'select_coin_start:BTC'], ['text' => 'TRC20', 'callback_data' => 'select_coin_start:USDT'], ['text' => 'TRX', 'callback_data' => 'select_coin_start:TRX']]]]
    ];

    return $data;
}


function input_address($sign)
{
    $data = [
        'text' => "Введите адрес {$sign}",
        'reply_markup' => ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'change_address']]]]
    ];

    return $data;
}

function input_address_start($sign)
{
    $data = [
        'text' => "Введите адрес {$sign}",
        'reply_markup' => ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'change_address_start']]]]
    ];

    return $data;
}

function update_sign($sign, $id)
{
    set_sign($sign, $id);
}

function update_change_sign($sign, $id)
{
    set_change_sign($sign, $id);
}

function update_address($address, $id)
{
    set_address($address, $id);
}

function get_admin_()
{
    $data = [
        'text' => "Вы в админ панели\n\n🔽 Выбери действие 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => 'Сайты', 'callback_data' => 'admin:site'], ['text' => 'Проценты', 'callback_data' => 'admin:proc']], [['text' => 'Настройка монет', 'callback_data' => 'admin:settings_coins']], [['text' => 'Настройка адреса', 'callback_data' => 'admin:address'], ['text' => 'Настройка процента', 'callback_data' => 'admin:procent']], [['text' => 'Блокировка стран', 'callback_data' => 'admin:block_ip_country'], ['text' => 'Заблокировать IP', 'callback_data' => 'admin:block_ip']]]]
    ];

    return $data;
}

function get_admin_site()
{
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);

    $temp = [];
    for ($i = 0; $i < count($json_a['site']); ++$i) {
        $temp = array_merge($temp, [[['text' => $json_a['site'][$i], 'callback_data' => "admin:adsite:{$i}"], ['text' => '❌', 'callback_data' => "admin:dele:{$i}"]]]);
    }

    $temp = array_merge($temp, [[['text' => 'Добавить сайт', 'callback_data' => 'admin:add_site']]]);
    $temp = array_merge($temp, [[['text' => '↩️ Назад', 'callback_data' => 'admin:admin']]]);

    $data = [
        'text' => "Сайты",
        'reply_markup' => ['inline_keyboard' => $temp]

    ];


    return $data;
}

function delete_site($site)
{
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);

    unset($json_a['site'][$site]);

    file_put_contents("admin.json", json_encode($json_a));
}

function create_add_site()
{
    $data = [
        'text' => 'Введите названия сайта',
        'reply_markup' => ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'admin:site']]]]
    ];

    return $data;
}

function add_site($site)
{
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);

    array_push($json_a['site'], $site);

    file_put_contents("admin.json", json_encode($json_a));
}

function get_procent()
{
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);
    $data = [
        'text' => "🧮 Проценты: {$json_a['first_proc']} / {$json_a['second_proc']} / {$json_a['three_proc']}\nВыберете процент, если хотите изменить\n\n🔽 Выбери действие 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => 'Первый', 'callback_data' => 'admin:first_proc'], ['text' => 'Второй', 'callback_data' => 'admin:second_proc']], [['text' => 'Третий', 'callback_data' => 'admin:three_proc']], [['text' => '↩️ Назад', 'callback_data' => 'admin:admin']]]]
    ];

    return $data;
}

function get_table_proc($call)
{
    $data = [
        'text' => "🔽 Выбери процент 🔽",
        'reply_markup' => ['inline_keyboard' => [[['text' => '10', 'callback_data' => "admin:change:{$call}:10"], ['text' => '20', 'callback_data' => "admin:change:{$call}:20"], ['text' => '30', 'callback_data' => "admin:change:{$call}:30"], ['text' => '40', 'callback_data' => "admin:change:{$call}:40"], ['text' => '50', 'callback_data' => "admin:change:{$call}:50"]], [['text' => '60', 'callback_data' => "admin:change:{$call}:60"], ['text' => '70', 'callback_data' => "admin:change:{$call}:70"], ['text' => '80', 'callback_data' => "admin:change:{$call}:80"], ['text' => '90', 'callback_data' => "admin:change:{$call}:90"], ['text' => '100', 'callback_data' => "admin:change:{$call}:100"]], [['text' => '↩️ Назад', 'callback_data' => 'admin:proc']]]]
    ];

    return $data;
}

function change_procent($call, $proc)
{
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);

    $json_a[$call] = $proc;

    file_put_contents("admin.json", json_encode($json_a));
}

function get_exchange_exchange($id, $type)
{
    $user = get_user($id);

    if ($type == 'check') {
        $exchanges = get_exchange_by_user($user['key'], 'waiting');
        $text = "Обмены в обработке\n";
    } elseif ($type == 'done') {
        $exchanges = get_exchange_by_user_pay($user['key']);
        $text = "Оплачены обменны\n";
    } elseif ($type == 'cancel') {
        $exchanges = get_exchange_by_user($user['key'], 'eror');
        $text = "Отмененны обменны\n";
    }

    $keyboard = [];

    while ($exchange = $exchanges->fetch_array()) {
        $keyboard = array_merge($keyboard, [[['text' => "{$exchange['ip']}📍{$exchange['id']}", 'callback_data' => "exchangeid:{$exchange['id']}"]]]);
    }

    $keyboard = array_merge($keyboard, [[['text' => '↩️ Назад', 'callback_data' => 'changes_status']]]);
    $data = [
        'text' => $text,
        'reply_markup' => ['inline_keyboard' => $keyboard]

    ];

    return $data;
}

function create_statistic_exchange($id)
{
    $exchange = get_exchange_id($id);
    $coin_from = get_coin_by_id($exchange['id_coin_from']);
    $coin_to = get_coin_by_id($exchange['id_coin_to']);
    $data = [];
    if ($exchange['status'] == 'check') {
        $text = "🟡 В обработке:";
        $data['reply_markup'] = ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'statistic_exchange:check']]]];
    } elseif ($exchange['status'] == 'done') {
        $text = "🟢 Принято:";
        $data['reply_markup'] = ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'statistic_exchange:done']]]];
    } elseif ($exchange['status'] == 'cancel') {
        $text = "🔴 Отклонено:";
        $data['reply_markup'] = ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'statistic_exchange:cancel']]]];
    } else {
        $text = "🔴 Ошибка:";
        $data['reply_markup'] = ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => 'statistic_exchange:eror']]]];
    }
    $text .= "Обмен: {$exchange['id']}\nДата создания: {$exchange['data']}\nСумма отправки: {$exchange['summ_from']} {$coin_from['sign']}\nСумма полуения: {$exchange['summ_to']} {$coin_to['sign']}\nАдрес мамонта: {$exchange['address']}\nПочта мамонта: {$exchange['mail']}";

    $data['text'] = $text;

    return $data;
}

function get_all_coins()
{
    $coins = get_exchange();
    $keyboard = [];
    while ($coin = $coins->fetch_array()) {
        $keyboard = array_merge($keyboard, [[['text' => $coin['name'], 'callback_data' => "admin:coin:{$coin['id']}"]]]);
    }

    $keyboard = array_merge($keyboard, [[['text' => '↩️ Назад', 'callback_data' => 'admin:admin']]]);

    $data = [
        'text' => 'Настройка монет',
        'reply_markup' => ['inline_keyboard' => $keyboard]

    ];

    return $data;
}


function create_setting_coin($id)
{
    $coin = get_coin_by_id($id);
    $from = 'ВЫКЛ';
    $to = 'ВЫКЛ';
    if ($coin['from'] == 1) {
        $from = 'ВКЛ';
    }
    if ($coin['to'] == 1) {
        $to = 'ВКЛ';
    }
    if ($coin['type'] == 'card') {
        $text = "{$coin['name']}\n\nSign: {$coin['sign']}\nProcent: {$coin['procent']}\nMin: {$coin['min']}\nMax: {$coin['max']}\nРеквизиты: {$coin['address']}\n\nНапрвления обмена\n\nИз: {$from}\nНа: {$to}";

        $data = [
            'text' => $text,
            'reply_markup' => [
                'inline_keyboard' => [
                    [['text' => "Из/{$from}", 'callback_data' => "admin:setcoin:from:{$coin['id']}"], ['text' => "На/{$to}", 'callback_data' => "admin:setcoin:to:{$coin['id']}"]],
                    [['text' => 'Сменить мин', 'callback_data' => "admin:setcoin:setmin:{$coin['id']}"], ['text' => 'Сменить макс', 'callback_data' => "admin:setcoin:setmax:{$coin['id']}"]],
                    [['text' => 'Сменить реквизиты', 'callback_data' => "admin:setcoin:address:{$coin['id']}"]],
                    [['text' => 'Сменить процент', 'callback_data' => "admin:setcoin:procent:{$coin['id']}"]],
                    [['text' => '↩️ Назад', 'callback_data' => "admin:settings_coins"]]
                ]
            ]

        ];
    } else {
        $text = "{$coin['name']}\n\nSign: {$coin['sign']}\nProcent: {$coin['procent']}\nMin: {$coin['min']}\nMax: {$coin['max']}\n\nНапрвления обмена\n\nИз: {$from}\nНа: {$to}";

        $data = [
            'text' => $text,
            'reply_markup' => [
                'inline_keyboard' => [
                    [['text' => "Из/{$from}", 'callback_data' => "admin:setcoin:from:{$coin['id']}"], ['text' => "На/{$to}", 'callback_data' => "admin:setcoin:to:{$coin['id']}"]],
                    [['text' => 'Сменить мин', 'callback_data' => "admin:setcoin:setmin:{$coin['id']}"], ['text' => 'Сменить макс', 'callback_data' => "admin:setcoin:setmax:{$coin['id']}"]],
                    [['text' => 'Сменить процент', 'callback_data' => "admin:setcoin:procent:{$coin['id']}"]],
                    [['text' => '↩️ Назад', 'callback_data' => "admin:settings_coins"]]
                ]
            ]

        ];
    }

    return $data;
}

function set_from_to($type, $id)
{
    $coin = get_coin_by_id($id);
    if ($type == 'from') {
        if ($coin['from'] == 1) {
            update_from(false, $id);
        } else {
            update_from(true, $id);
        }
    } else {
        if ($coin['to'] == 1) {
            update_to(false, $id);
        } else {
            update_to(true, $id);
        }
    }
}

function change_min($summ, $id_coin)
{
    update_min_coin($summ, $id_coin);
}

function change_max($summ, $id_coin)
{
    update_max_coin($summ, $id_coin);
}

function change_procent_coin($proc, $id_coin)
{
    update_procent_coin($proc, $id_coin);
}

function change_address_coin($address, $id_coin)
{
    update_address_coin($address, $id_coin);
}

function defolt_address()
{
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);

    $address = $json_a["address"];

    $text = "Дефолтный адрес для карт:\n{$address}";
    $data['reply_markup'] = ['inline_keyboard' => [[['text' => 'Сменить адрес', 'callback_data' => 'admin:set_addres_']], [['text' => '↩️ Назад', 'callback_data' => 'admin:admin']]]];
    $data['text'] = $text;

    return $data;
}

function defolt_procent()
{
    $file_admin = file_get_contents("admin.json");
    $json_a = json_decode($file_admin, true);

    $address = $json_a["procent"];

    $text = "Дефолтный процент:\n{$address}";
    $data['reply_markup'] = ['inline_keyboard' => [[['text' => 'Сменить процент', 'callback_data' => 'admin:set_procent_']], [['text' => '↩️ Назад', 'callback_data' => 'admin:admin']]]];
    $data['text'] = $text;

    return $data;
}

function block_ip_country()
{
    $countrys = get_all_block_country();
    $keyboard = [];
    while ($country = $countrys->fetch_array()) {
        if ($country['block'] == 1) {
            $keyboard = array_merge($keyboard, [[['text' => $country['contry'] . " ✅", 'callback_data' => "admin:country_block:{$country['id']}"]]]);
        } else {
            $keyboard = array_merge($keyboard, [[['text' => $country['contry'] . " 🚫", 'callback_data' => "admin:country_block:{$country['id']}"]]]);
        }
    }

    $keyboard = array_merge($keyboard, [[['text' => '↩️ Назад', 'callback_data' => 'admin:admin']]]);

    $data = [
        'text' => 'Блокировка стран',
        'reply_markup' => ['inline_keyboard' => $keyboard]

    ];

    return $data;
}

function change_block_country_($id)
{
    $country = get_block_country_by_id($id);
    if ($country['block'] == 0) {
        set_block_country($id, 1);
    } else {
        set_block_country($id, 0);
    }
}

function block_ip_user()
{
    $data = [
        'text' => "Введите IP который хотите заблокировать",
        'reply_markup' => ['inline_keyboard' => [[['text' => '🚫 Отменить', 'callback_data' => "admin:admin"]]]]

    ];

    return $data;
}

function add_ip_block_($ip)
{
    add_ip_block($ip);
}


function create_JWT()
{
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.nowpayments.io/v1/auth',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => '{
        "email": "' . email_nowpay . '",
        "password": "' . password_nowpay . '" 
    }',
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
        ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    $result = json_decode(json_encode(json_decode($response)), true);
    return $result['token'];
}

function send_summ($address, $currency, $amount)
{
    $amount = round($amount, 6);
    if ($currency == 'USDT') {
        $currency = 'USDTTRC20';
    }
    $url = 'https://api.nowpayments.io/v1/payout';
    $headers = ['x-api-key: ' . api_nowpay, 'Content-Type: application/json', 'Authorization: Bearer ' . create_JWT()];
    $data = json_encode(array('address' => $address, 'currency' => $currency, 'amount' => $amount));
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);


    $result = curl_exec($ch);
    curl_close($ch);
    $result = json_decode(json_encode(json_decode($result)), true);
}

function send_paymnets_to_chanel($summ_all, $proc, $worker)
{


    $text = "💸 Сумма: {$summ_all}$
    🔱 Процент: {$proc}%
    🧑‍💻 Воркер: @{$worker}";
    $data = ['text' => $text, 'chat_id' => payments_channel];
    $method = 'sendMessage';
    $headers = [];
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_POST => 1,
        CURLOPT_HEADER => 0,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => 'https://api.telegram.org/bot' . TOKEN . '/' . $method,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => array_merge(array("Content-Type: application/json"), $headers)
    ]);

    $result = curl_exec($curl);
    curl_close($curl);
}

function exchange_solution_admin($exchange, $status)
{
    // $coin_from = get_coin_by_id($exchange['id_coin_from']);
    // $kurs = get_kurs_bot($coin_from['sign'], 'USD');
    set_exchange_status($exchange['id'], $status);
    // $sum_usd = round($exchange['summ_from'] * $kurs, 0);
    // $worker = get_user_by_key($exchange['key']);
    // change_balance_user($worker['id'], $sum_usd + $worker['balance']);
    // change_balance_all_user($worker['id'], $sum_usd + $worker['balance_all']);
}
// function exchange_solution_admin($type, $exchange, $status)
// {
//     if ($type == 'crypto') {
//         if ($status == 'done') {
//             $coin_to = get_coin_by_id($exchange['id_coin_to']);
//             if ($coin_to['type'] == 'crypto') {
//                 send_summ($exchange['address_to'], $coin_to['sign'], $exchange['summ_to']);
//             }
//             set_exchange_status($exchange['id'], 'done');
//         } elseif ($status == 'cancel') {
//             $worker = get_user_by_key($exchange['key']);
//             if ($exchange['key'] != 'None' && $worker != null) {
//                 $count_worker = get_count_exchange_worker($exchange['key'], $exchange['ip']);
//                 $file_admin = file_get_contents("admin.json");
//                 $json_a = json_decode($file_admin, true);
//                 if ($count_worker == 1) {
//                     $percent = (int) $json_a['first_proc'];
//                 } elseif ($count_worker == 2) {
//                     $percent = (int) $json_a['second_proc'];
//                 } else {
//                     $percent = (int) $json_a['three_proc'];
//                 }
//                 $prcie = (float) $exchange['summ_from'];
//                 $summ = $prcie * ($percent / 100);
//                 $kurs = get_kurs_bot($worker['sign'], 'USD');
//                 $channel_price = round($prcie * $kurs, 2);
//                 $summ_usd = round($summ * $kurs, 2);
//                 send_summ($worker['address'], $worker['sign'], $summ);
//                 send_paymnets_to_chanel($channel_price, $percent, $worker['username']);
//                 set_balance($worker['id'], $summ_usd);
//             }
//             set_exchange_status($exchange['id'], 'cancel');
//         } else {
//             set_exchange_status($exchange['id'], 'eror');
//         }
//     } elseif ($type == 'card') {
//         if ($status == 'done') {
//             set_exchange_status($exchange['id'], 'done');
//         } elseif ($status == 'cancel') {
//             set_exchange_status($exchange['id'], 'cancel');
//         } else {
//             set_exchange_status($exchange['id'], 'eror');
//         }
//     } else {
//         set_exchange_status($exchange['id'], 'eror');
//     }
// }

function get_kurs_bot($first, $second)
{
    if ($first == 'TRC20' || $first == 'ERC20') {
        $first = 'usdt';
    } 
     
    if ($second == 'TRC20' || $second == 'ERC20') {
        $second = 'usdt';
    }

    $api = api_nowpay;
    $url = 'https://api.nowpayments.io/v1/estimate?amount=1&currency_from=' . $first . '&currency_to=' . $second;

    $options = array(
        'x-api-key: ' . $api
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $options);
    $result = curl_exec($ch);
    curl_close($ch);

    return $result;
}

function send_admin_payments($worker)
{
    $data = [
        'text' => "‼️ Выплата ‼️\n👨‍💻 Воркер: {$worker['username']}\n💸 Валюта: {$worker['sign']}\n♻️ Адрес: {$worker['address']}\n🤑 Сумма: {$worker['balance']} $",
        'reply_markup' => ['inline_keyboard' => [[['text' => 'Подтвердить', 'callback_data' => "payment_d:{$worker['id']}:{$worker['balance']}"], ['text' => 'Отменить', 'callback_data' => "payments_c:{$worker['id']}:{$worker['balance']}"]]]],
        'chat_id' => admin_chat,
    ];

    $method = 'sendMessage';
    $headers = [];
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_POST => 1,
        CURLOPT_HEADER => 0,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => 'https://api.telegram.org/bot' . TOKEN . '/' . $method,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => array_merge(array("Content-Type: application/json"), $headers)
    ]);

    $result = curl_exec($curl);
    curl_close($curl);
}

function get_order_payments($id)
{
    $worker = get_user($id);
    if ($worker['balance'] < 50) {
        return false;
    } else {
        $data = [
            'text' => "💎 Вы заказали выплату на сумму {$worker['balance']} $\n\n⚙️ Данные выплаты ⚙️\n💸 Валюта: {$worker['sign']}\n♻️ Адрес: {$worker['address']}\n\n❗️❕Оплата будет после подтверждения админа❕❗️",
            'reply_markup' => ['inline_keyboard' => [[['text' => '↩️ Назад', 'callback_data' => "finance"]]]]

        ];
        send_admin_payments($worker);

        return $data;
    }
}

function done_payment_channel($id_worker, $summ_usd)
{
    $worker = get_user($id_worker);
    $summ = $worker['balance'] - $summ_usd;
    if ($summ < 0) {
        $summ = 0;
    }
    add_pays($worker['id'], $summ_usd);
    change_balance_user($worker['id'], $summ);
    $data = [
        'text' => "⚜️ Админ подтвердил выплату на сумму {$summ_usd} $",
        'chat_id' => $id_worker
    ];
    $method = 'sendMessage';
    $headers = [];
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_POST => 1,
        CURLOPT_HEADER => 0,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => 'https://api.telegram.org/bot' . TOKEN . '/' . $method,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => array_merge(array("Content-Type: application/json"), $headers)
    ]);

    $result = curl_exec($curl);
    curl_close($curl);
    $data = [
        'text' => "✔️ Выплачено ✔️\n👨‍💻 Воркер: {$worker['username']}\n💸 Валюта: {$worker['sign']}\n♻️ Адрес: {$worker['address']}\n🤑 Сумма: {$summ_usd} $"
    ];

    return $data;
}

function cancel_payment_channel($id_worker, $summ_usd)
{
    $worker = get_user($id_worker);
    $data = [
        'text' => "❗️ Админ отменил выплату на сумму {$summ_usd}$",
        'chat_id' => $id_worker
    ];
    $method = 'sendMessage';
    $headers = [];
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_POST => 1,
        CURLOPT_HEADER => 0,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => 'https://api.telegram.org/bot' . TOKEN . '/' . $method,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => array_merge(array("Content-Type: application/json"), $headers)
    ]);

    $result = curl_exec($curl);
    curl_close($curl);
    $data = [
        'text' => "❌ Отменено ❌\n👨‍💻 Воркер: {$worker['username']}\n💸 Валюта: {$worker['sign']}\n♻️ Адрес: {$worker['address']}\n🤑 Сумма: {$summ_usd} $"
    ];

    return $data;
}

function get_history_payments($id, $type, $num)
{

    if ($type == 'back') {
        $back = $num - 1;
        $next = $num;
    } else {
        $back = $num;
        $next = $num + 1;
    }
    $pays = get_history_peayments($id, $back * 5, $next * 5 + 1);


    $keyboard = [];
    $n = 0;
    $pays_two = false;
    while ($pay = $pays->fetch_array()) {
        $n = $n + 1;
        $keyboard = array_merge($keyboard, [[['text' => "{$pay['summ']} дол📍{$pay['id']}", 'callback_data' => "payid:{$pay['id']}:{$num}"]]]);
        if ($n == 5) {
            $pays_two = true;
            break;
        }
    }
    if ($n == 0) {
        return false;
    } else {

        if ($pays_two != false && $back != 0) {
            $keyboard = array_merge($keyboard, [[['text' => '◀️ Назад', 'callback_data' => "history_payment:back:{$back}"], ['text' => '▶️ Вперед', 'callback_data' => "history_payment:next:{$next}"]]]);
        } elseif ($pays_two == false && $back != 0) {
            $keyboard = array_merge($keyboard, [[['text' => '◀️ Назад', 'callback_data' => "history_payment:back:{$back}"]]]);
        } elseif ($pays_two != false && $back == 0) {
            $keyboard = array_merge($keyboard, [[['text' => '▶️ Вперед', 'callback_data' => "history_payment:next:{$next}"]]]);
        }
        $keyboard = array_merge($keyboard, [[['text' => 'На финансы', 'callback_data' => "finance"]]]);

        $data = [
            'text' => "История выплат",
            'reply_markup' => ['inline_keyboard' => $keyboard]
        ];

        return $data;
    }
}
