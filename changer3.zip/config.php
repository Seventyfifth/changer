<?php
define('sitename', 'ClickChange');
define('support_tg', 'link');

define('servername', 'localhost');
define('db', 'swiftyara1');
define('user', 'swift1');
define('password', 'Swift1');
define('port', 3306);

define('api_nowpay', '3WEQ7MB-KPJMZMP-NHJXHAD-HTJH78T');

define('TOKEN', '7255921374:AAHO6LqZ7RjeyssWt2pw35mGomyXnVGXUno');
define('admin', '5410029994');
define('admin_chat', '5410029994');
define('payments_channel', '5410029994');
define('work_chat_link', 'https://t.me/+CiWNBzGOn95mMDEy');
define('payment_chanel_link', 'https://t.me/+CiWNBzGOn95mMDEy');
define('verification_link', 'none');
    
