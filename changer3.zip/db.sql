-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 12 2023 г., 19:23
-- Версия сервера: 10.5.16-MariaDB-cll-lve
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `u418772814_clickchange`
--

-- --------------------------------------------------------

--
-- Структура таблицы `block_ips`
--

CREATE TABLE `block_ips` (
  `id` mediumint(9) NOT NULL,
  `ip` text DEFAULT NULL,
  `block` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `coins`
--

CREATE TABLE `coins` (
  `id` mediumint(9) NOT NULL,
  `sign` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `icon` text DEFAULT NULL,
  `type` text DEFAULT NULL,
  `from` tinyint(1) DEFAULT NULL,
  `to` tinyint(1) DEFAULT NULL,
  `procent` float DEFAULT NULL,
  `min` float DEFAULT NULL,
  `max` float DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `coins`
--

INSERT INTO `coins` (`id`, `sign`, `name`, `icon`, `type`, `from`, `to`, `procent`, `min`, `max`, `address`) VALUES
(1, 'BTC', 'Bitcoin', 'btc.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(2, 'ETH', 'Ethereum', 'eth.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(3, 'ADA', 'Cardano', 'ada.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(4, 'BNBBSC', 'Binance-Coin', 'bnb.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(5, 'DASH', 'Dash', 'dash.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(6, 'DOGE', 'Dogecoin', 'doge.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(7, 'LTC', 'Litecoin', 'ltc.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(8, 'XMR', 'Monero', 'xmr.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(9, 'TRX', 'Tron', 'trx.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(10, 'USDTTRC20', 'Tether(TRC-20)', 'usdt.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(11, 'USDTERC20', 'Tether(ERC-20)', 'usdt.svg', 'crypto', 1, 1, NULL, NULL, NULL, NULL),
(12, 'RUB', 'Tinkoff', 'tinkoff.svg', 'card', 0, 1, NULL, NULL, NULL, NULL),
(13, 'RUB', 'Sberbank', 'sberbank.svg', 'card', 0, 1, NULL, NULL, NULL, NULL),
(14, 'RUB', 'Qiwi', 'qiwi.svg', 'card', 0, 1, NULL, NULL, NULL, NULL),
(15, 'RUB', 'VTB', 'vtb.svg', 'card', 0, 1, NULL, NULL, NULL, NULL),
(16, 'USD', 'Visa/Mastercard(USD)', 'visamastercard.svg', 'card', 0, 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `countries`
--

CREATE TABLE `countries` (
  `id` mediumint(9) NOT NULL,
  `contry` text DEFAULT NULL,
  `block` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `countries`
--

INSERT INTO `countries` (`id`, `contry`, `block`) VALUES
(2, 'RU', 0),
(3, 'EN', 0),
(4, 'US', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `exchanges`
--

CREATE TABLE `exchanges` (
  `id` mediumint(9) NOT NULL,
  `id_coin_from` int(11) DEFAULT NULL,
  `id_coin_to` int(11) DEFAULT NULL,
  `summ_from` float DEFAULT NULL,
  `summ_to` float DEFAULT NULL,
  `data` text DEFAULT NULL,
  `key` text DEFAULT NULL,
  `ip` text DEFAULT NULL,
  `kurs` float DEFAULT NULL,
  `address` text DEFAULT NULL,
  `address_to` text DEFAULT NULL,
  `status` text DEFAULT NULL,
  `mail` text DEFAULT NULL,
  `pay_id` text DEFAULT NULL,
  `pay` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `mamonts`
--

CREATE TABLE `mamonts` (
  `id` mediumint(9) NOT NULL,
  `login` text DEFAULT NULL,
  `mail` text DEFAULT NULL,
  `password` text DEFAULT NULL,
  `key` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `ref_key` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `pays`
--

CREATE TABLE `pays` (
  `id` mediumint(9) NOT NULL,
  `id_worker` bigint(20) DEFAULT NULL,
  `summ` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` mediumint(9) NOT NULL,
  `name-ru` text NOT NULL,
  `name-en` text NOT NULL,
  `descriptions-ru` text NOT NULL,
  `descriptions-en` text NOT NULL,
  `data` text NOT NULL,
  `show` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `name-ru`, `name-en`, `descriptions-ru`, `descriptions-en`, `data`, `show`) VALUES
(1, 'Александр', 'Alexander', 'Благодарю за очень быстрый обмен! Пользуюсь впервые этим обменником,точно не последний.', 'Thank you for a very quick exchange! I use this exchanger for the first time, definitely not the last one.', '08.01.23', 7),
(2, 'Олег', 'Oleg', 'Совершал несколько раз обмен на этом ресурсе, приходит быстро, общался с поддержкой ответили сразу.', 'I made an exchange several times on this resource, it comes quickly, I communicated with support and they answered immediately.', '10.01.23', 9),
(3, 'Артур', 'Arthur', 'Сервис работает, обменивал несколько раз TRX на малые суммы.', 'The service is working, I have exchanged TRX for small amounts several times.', '11.01.23', 10),
(4, 'Николай', 'Nikolay', 'Неплохой обменник, использую редко, но ни разу не подводил.', 'A good exchanger, I rarely use it, but I have never failed.', '12.01.23', 1),
(5, 'Роман', 'Novel', 'Удобно, достаточно оперативно и весь процесс обмена интуитивно понятен и нагляден, включая подтверждение и прочее.', 'It is convenient, fast enough and the whole exchange process is intuitive and visual, including confirmation and so on.', '25.12.22', 2),
(6, 'Наталья', 'Natalya', 'Рекомендую к обмену, особенно учитывая нынешнюю ситуацию с обменом крипты (не с холодных кошельков).', 'I recommend to exchange, especially considering the current situation with the exchange of crypts (not from cold wallets).', '26.12.22', 3),
(7, 'Макс', 'Max', 'Отличный сервис. Спасибо', 'Great service. Thank you', '27.12.22', 4),
(8, 'Дарья', 'Daria', 'Вау, такой прекрасный сервис, спасибо огромное!', 'Wow, such a great service, thank you so much!', '28.12.22', 5),
(9, 'Владимир', 'Vladimir', 'Весь перевод занял 10 минут.всё понравилось.!', 'The entire translation took 10 minutes.I liked everything.!', '07.01.23', 6),
(10, 'Евгений', 'Evgeniy', 'Хороший обменник. Несколько раз использовал. Зашло)', 'A good exchanger. I used it several times. Gone)', '09.01.23', 8);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint(20) DEFAULT NULL,
  `username` text DEFAULT NULL,
  `first_name` text DEFAULT NULL,
  `apply` tinyint(1) DEFAULT NULL,
  `step_apply` int(11) DEFAULT NULL,
  `resource` text DEFAULT NULL,
  `experience` text DEFAULT NULL,
  `msg` int(11) DEFAULT NULL,
  `cancel` tinyint(1) DEFAULT NULL,
  `sign` text DEFAULT NULL,
  `change_sign` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `key` text DEFAULT NULL,
  `balance` int(11) DEFAULT NULL,
  `balance_all` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `block_ips`
--
ALTER TABLE `block_ips`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `coins`
--
ALTER TABLE `coins`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `exchanges`
--
ALTER TABLE `exchanges`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `mamonts`
--
ALTER TABLE `mamonts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `pays`
--
ALTER TABLE `pays`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `block_ips`
--
ALTER TABLE `block_ips`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `coins`
--
ALTER TABLE `coins`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `countries`
--
ALTER TABLE `countries`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `exchanges`
--
ALTER TABLE `exchanges`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `mamonts`
--
ALTER TABLE `mamonts`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `pays`
--
ALTER TABLE `pays`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
