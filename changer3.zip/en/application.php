<!DOCTYPE html>
<html lang="en">

<?php
include('../layout/en/head.php');
include('../vender/logic.php');
$block = check_ip();
if ($block == false) {
    header('Location: ' . 'en/error.php');
}
?>
<?php
// $name_from = str_replace(" ", '', $_GET['name_from']);;
// $sign_from = $_GET['sign_from'];
// $name_to = str_replace(" ", '', $_GET['name_to']);
// $sign_to = $_GET['sign_to'];
// $address = $_GET['address'];
// $summa_from = $_GET['summa_from'];
// $summa_to = $_GET['summa_to'];
// $coin_from = get_coin_by_name($name_from);
// $coin_to = get_coin_by_name($name_to);
// if(empty($name_from) or empty($sign_from) or empty($name_to) or empty($sign_to) or empty($address) or empty($summa_from) or empty($summa_to) or $coin_from == null or $coin_to == null){
//     header('Location: '.'index.php');
// }

// $kurs = json_decode(get_kurs($sign_from, $sign_to), true);
// $kurs_to = $kurs[$sign_to];
// $address_to = 'asdasd';
// $create_date = date("m.d.y H:i");
$exchange_id = $_GET['exchange_id'];
$exchange = get_exchange_id($exchange_id);
if ($exchange['ip'] != get_ip()) {
    header('Location: ' . 'en/index.php');
}
$coin_from = get_coin_by_id($exchange['id_coin_from']);
$coin_to = get_coin_by_id($exchange['id_coin_to']);
?>

<body>

    <div class="wrapper">
        <div class="preloader">
            <div class="preloader__loader"></div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/en/header_reg.php');
        } else {
            include('../layout/en/header.php');
        }
        ?>
        <main class="main">
            <section class="application">
                <div class="container application__container">
                    <div class="application__start wow animate__fadeInLeft" data-wow-delat=".25s">
                        <h1 class="title application__title">
                            Application <span><?php
                                                echo $exchange['id'];
                                                ?></span>
                        </h1>
                        <h2 class="title application__subtitle">
                            Pair to exchange
                        </h2>
                        <div class="application__blocks">
                            <div class="application__block">
                                <?php
                                if ($coin_from['type'] == 'crypto') {
                                    echo '<img class="application__block-img" src="../img/coins/' . $coin_from['icon'] . '" alt="coin">';
                                } elseif ($coin_from['type'] == 'card') {
                                    echo '<img class="application__block-img" src="../img/banks/' . $coin_from['icon'] . '" alt="bank">';
                                }
                                ?>
                                <div class="application__block-wrapper">
                                    <div class="application__block-title">
                                        <?php
                                        echo $coin_from['name'];
                                        ?>
                                    </div>
                                    <div class="application__block-subtitle">
                                        <?php
                                        echo "{$exchange['summ_from']}";
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="application__block">
                                <?php
                                if ($coin_to['type'] == 'crypto') {
                                    echo '<img class="application__block-img" src="../img/coins/' . $coin_to['icon'] . '" alt="coin">';
                                } elseif ($coin_to['type'] == 'card') {
                                    echo '<img class="application__block-img" src="../img/banks/' . $coin_to['icon'] . '" alt="bank">';
                                }
                                ?>
                                <div class="application__block-wrapper">
                                    <div class="application__block-title">
                                        <?php
                                        echo $coin_to['name'];
                                        ?>
                                    </div>
                                    <div class="application__block-subtitle">
                                        <?php
                                        echo "{$exchange['summ_to']}";
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="application__block">
                                <img class="application__block-img" src="../img/icons/change.png" alt="change">
                                <div class="application__block-wrapper">
                                    <div class="application__block-title">
                                        End details
                                    </div>
                                    <div class="application__block-subtitle">
                                        <?php
                                        echo $exchange['address'];
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="application__wrapper">
                            <div class="btn btn_background_blue application__fixed">Fixed</div>
                            <div class="btn btn_border_gray application__time" id="small_ticket">30:00</div>
                        </div>
                        <h3 class="title application__title_small" id="fixed_kurs">
                            <?php
                            echo "The course is fixed for 30 minutes at the value{$exchange['kurs']} {$coin_to['sign']}";
                            ?>
                        </h3>
                        <p class="application__text" id="info_text">
                            If the 1st network confirmation is not received within this time, the rate will be
                            fixed at the time of receiving the 1st confirmation. The exchange will be done automatically,
                            after the 1st confirmation of your transaction on the network
                        </p>
                        <div class="application__payments">
                            <div class="application__payment">
                                <div class="step step_active application__payment-step">
                                    1
                                </div>
                                <div class="application__payment-wrapper">
                                    <div class="application__payment-title">
                                        Payment processing
                                    </div>
                                    <p class="application__payment-text wd-300">
                                        After you send your payment, our robot will automatically see your
                                        transaction. You do not need to click anywhere or write to support
                                    </p>
                                </div>
                            </div>
                            <div class="application__payment">
                                <div class="step application__payment-step">
                                    2
                                </div>
                                <div class="application__payment-wrapper">
                                    <div class="application__payment-title application__payment-title_light">
                                        Translation
                                    </div>
                                    <p class="application__payment-text application__payment-text_light wd-200">
                                        After we receive your payment, our system will immediately transfer your
                                        funds
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="application__end wow animate__fadeInRight" data-wow-delat=".25s">
                        <div class="application__timer">
                            <div class="application__timer-border"></div>
                            <div class="application__timer-title">
                                Time
                            </div>
                            <div class="application__timer-time">
                                30:00
                            </div>
                        </div>
                        <div class="panel application__panel" id="exchange">
                            <div class="panel__top">
                                <h3 class="title application__panel-title">
                                    Submit here
                                </h3>
                            </div>
                            <div class="panel__line application__panel-line">
                                <div></div>
                            </div>
                            <div class="panel__bottom">
                                <div class="application__panel-block">
                                    <?php
                                    if ($coin_from['type'] == 'crypto') {
                                        echo '<img class="application__panel-block-img" src="../img/coins/' . $coin_from['icon'] . '" alt="coin">';
                                    } elseif ($coin_from['type'] == 'card') {
                                        echo '<img class="application__panel-block-img" src="../img/banks/' . $coin_from['icon'] . '" alt="bank">';
                                    }
                                    ?>
                                    <div class="application__panel-block-wrapper">
                                        <div class="application__panel-block-title">
                                            You're sending
                                        </div>
                                        <div class="application__panel-block-subtitle">
                                            <?php
                                            echo $exchange['summ_from'] . ' ' . $coin_from['sign'];
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="application__block application__block-copy">
                                    <div class="application__block-wrapper">
                                        <div class="application__block-title">
                                            To our details
                                        </div>
                                        <div class="application__block-subtitle">
                                            <?php
                                            echo $exchange['address_to'];
                                            ?>
                                        </div>
                                    </div>
                                    <input class="input" type="text" value="<?php
                                                                            echo $exchange['address_to'];
                                                                            ?>" style="display: none;">
                                    <a class="btn btn_background_blue application__btn input__copy" href="#">
                                        <img src="../img/icons/copy.png" alt="copy">
                                    </a>
                                </div>
                                <?php
                                if ($coin_from['type'] == 'crypto') {
                                    echo '<div class="application__panel-block">
                                            <img class="mr-24 application__qr" src="https://chart.googleapis.com/chart?chs=177x177&amp;cht=qr&amp;chl=' . $exchange['address_to'] . '&choe=UTF-8"
                                                alt="QR code">
                                            <div class="application__panel-block-wrapper">
                                                <div class="application__panel-block-subtitle">
                                                QR code for in-app payment
                                                </div>
                                                <div class="application__panel-block-title mt-10">
                                                Point the camera while translating from the app
                                                </div>
                                            </div>
                                        </div>';
                                }
                                ?>

                                <div class="application__wrapper-info">
                                    <h3 class="title application__title_small">
                                        Already paid?
                                    </h3>
                                    <p class="application__text">
                                        After completing the transaction using our details, click on the “I paid” button below.
                                        After that the process of fulfilling your application will begin
                                    </p>
                                    <a class="btn btn_background_blue application__btn-payed mt-20" href="#">I paid</a>
                                </div>
                            </div>
                        </div>
                        <div class="application__date">
                            <div class="application__date-img">
                                <img src="../img/icons/calendar.png" alt="calendar">
                            </div>
                            <div class="application__date-wrapper">
                                <div class="application__date-title">
                                    Application creation date
                                </div>
                                <div class="application__date-subtitle">
                                    <?php
                                    echo $exchange['data'];
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="panel application__panel" id="done_exchange" style="min-height:0px;display:none;margin-top:20px;">
                            <div class="panel__top">
                                <h3 class="title application__panel-title">
                                    Translation completed
                                </h3>
                            </div>
                            <div class="panel__line application__panel-line">
                                <div></div>
                            </div>
                            <div class="panel__bottom">
                                <div class="application__wrapper-info">
                                    <h3 class="title application__title_small">
                                        Funds paid out
                                    </h3>
                                    <p class="application__text">
                                        Thank you for using our services!
                                        don't forget to leave a review about us. We will wait for you again!
                                    </p>
                                    <a class="btn btn_background_blue mt-20" href="index.php">To main</a>
                                </div>
                            </div>
                        </div>
                        <div class="panel application__panel" id="eror_exchange" style="min-height:0px;display:none;margin-top:20px;">
                            <div class="panel__top">
                                <h3 class="title application__panel-title">
                                    Application error
                                </h3>
                            </div>
                            <div class="panel__line application__panel-line">
                                <div></div>
                            </div>
                            <div class="panel__bottom">

                                <div class="application__wrapper-info">
                                    <h3 class="title application__title_small">
                                        Funds not paid
                                    </h3>
                                    <p class="application__text">
                                        We were unable to complete this transfer due to some
                                        errors. Please try again or contact support.
                                    </p>
                                    <a class="btn btn_background_blue mt-20" href="index.php">To main</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <section class="attention">
                <div class="container attention__container">
                    <h3 class="title attention__title">
                        Attention!
                    </h3>
                    <p class="attention__subtitle">
                        Please note that the service does not accept funds from high-risk sources.
                        Each incoming transaction is verified through an independent AML service. If
                        the transaction has more than 70% risk, such payments will be suspended. And after passing
                        identity verification, they will be returned to you minus the network commission! The exchange of such funds
                        impossible! We recommend to increase the commission in the system in order to speed up the transaction
                        Bitcoin.
                    </p>
                    <input value="<?php
                                    echo $exchange['id']
                                    ?>" id="id_exchage" type="hidden">
                </div>
            </section>
        </main>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/en/footer_reg.php');
        } else {
            include('../layout/en/footer.php');
        }
        ?>
    </div>

    <script src="../js/libs/jquery-3.6.1.min.js"></script>
    <script src="../js/libs/wow.min.js"></script>
    <script src="../js/script.js"></script>
    <script>
        if (localStorage.getItem('i_payment:' + $('#id_exchage').val())) {
            $(".application__wrapper-info").slideToggle(1000);
            $(".step").removeClass("step_active");
            $(".application__payment-title").addClass(
                "application__payment-title_light"
            );
            $(".application__payment-text").addClass("application__payment-text_light");
            $(".application__payment:nth-child(2) .step").addClass("step_active");
            $(
                ".application__payment:nth-child(2) .application__payment-title"
            ).removeClass("application__payment-title_light");
            $(
                ".application__payment:nth-child(2) .application__payment-text"
            ).removeClass("application__payment-text_light");
        }
        var id_exchage = <?php
                            echo $exchange['id']
                            ?>

        var type = "<?php
                    echo $coin_from['type']
                    ?>"


        if (localStorage.getItem('order:' + id_exchage)) {
            var time = localStorage.getItem('order:' + id_exchage)
        } else {

            var time = 30 * 60
            localStorage.setItem('order:' + id_exchage, time);
        }

        var status = 'waiting'
        const check_exchange = setInterval(() => {
            if (status == 'waiting') {
                if (localStorage.getItem('i_payment:' + $('#id_exchage').val())) {
                    var payment = "pay";
                } else {
                    var payment = "not_pay";
                }
                $.ajax({
                    url: '/vender/check_exchange.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        'id': id_exchage,
                        'type': type,
                        'payment': payment
                    },
                    success(data) {
                        if (data.status == 'waiting' || data.status == 'check') {
                            //pass
                        } else if (data.status == 'confirming') {
                            clearInterval(ticket);
                        } else if (data.status == 'done') {
                            change_();
                            $('#exchange').css("display", "none");
                            $('#done_exchange').css("display", "block");
                            $(".application__wrapper-info").css("display", "block");
                            status = data.status
                        } else {
                            change_();
                            $('#exchange').css("display", "none");
                            $('#eror_exchange').css("display", "block");
                            $(".application__wrapper-info").css("display", "block");
                            status = data.status
                        }
                    }
                })
            }
        }, 1000);

        function change_() {
            $('.application__wrapper').css("display", "none");
            $('.application__timer').css("display", "none");
            $('#fixed_kurs').css("display", "none");
            $('#info_text').css("display", "none");
            $('.application__payments').css("display", "none");
        }

        const ticket = setInterval(() => {
            time--;
            const minutes = Math.floor(time / 60);
            const seconds = time - minutes * 60;
            $('.application__timer-time').text(`${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);
            $('#small_ticket').text(`${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);
            localStorage.setItem('order:' + id_exchage, time);
            if (time == 0) {
                clearInterval(ticket)
                localStorage.removeItem('order:' + id_exchage);
                $.ajax({
                    url: '/vender/close_exchange.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        'id': id_exchage
                    }
                })
            }


        }, 1000);
    </script>
</body>

</html>