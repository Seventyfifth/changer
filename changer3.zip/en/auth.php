<!DOCTYPE html>
<html lang="en">

<?php
include('../layout/en/head.php');
include('../vender/logic.php');
include('./config.php');
$sitename = sitename;
$block = check_ip();
if ($block == false) {
    header('Location: ' . 'error.php');
}

?>

<body>

    <div class="wrapper" style="height: 100vh; overflow: hidden;">
        <div class="preloader">
            <div class="preloader__loader"></div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            header('Location: ' . '/en/account.php');
        } else {
            include('../layout/en/header.php');
        }
        ?>
        <main class="main">
            <div class="shapes shapes_top_100">
                <div class="container shapes__container">
                    <img class="shapes__img shapes__img_1 wow animate__fadeInUp" data-wow-delay=".5s" src="../img/shapes/1.png" alt="shape">
                    <img class="shapes__img shapes__img_2 wow animate__fadeInUp" data-wow-delay=".15s" src="../img/shapes/2.png" alt="shape">
                    <img class="shapes__img shapes__img_3 wow animate__fadeInUp" data-wow-delay=".25s" src="../img/shapes/3.png" alt="shape">
                    <img class="shapes__img shapes__img_4 wow animate__fadeInUp" data-wow-delay=".35s" src="../img/shapes/4.png" alt="shape">
                    <img class="shapes__img shapes__img_5 wow animate__fadeInUp" data-wow-delay=".45s" src="../img/shapes/5.png" alt="shape">
                    <img class="shapes__img shapes__img_6 wow animate__fadeInUp" data-wow-delay=".5s" src="../img/shapes/6.png" alt="shape">
                    <img class="shapes__img shapes__img_7 wow animate__fadeInUp" data-wow-delay=".15s" src="../img/shapes/7.png" alt="shape">
                    <img class="shapes__img shapes__img_8 wow animate__fadeInUp" data-wow-delay=".25s" src="../img/shapes/8.png" alt="shape">
                    <img class="shapes__img shapes__img_9 wow animate__fadeInUp" data-wow-delay=".35s" src="../img/shapes/9.png" alt="shape">
                    <img class="shapes__img shapes__img_10 wow animate__fadeInUp" data-wow-delay=".45s" src="../img/shapes/10.png" alt="shape">
                </div>
            </div>
            <section class="auth">
                <div class="container auth__container">
                    <div class="panel auth__panel wow animate__fadeIn" data-wow-delay=".5s">
                        <div class="panel__top">
                            <div class="panel__wrapper">
                                <?php
                                if ($_GET["auth"] == 'signin') {
                                    echo '<a class="panel__link panel__link_active" href="#" data-page="signin">Authorization</a>';
                                    echo '<a class="panel__link" href="#" data-page="signup">Registration</a>';
                                } else {
                                    echo '<a class="panel__link" href="#" data-page="signin">Authorization</a>';
                                    echo '<a class="panel__link panel__link_active" href="#" data-page="signup">Registration</a>';
                                }
                                ?>

                            </div>
                        </div>
                        <div class="panel__line"></div>
                        <div class="panel__bottom">
                            <?php
                            if ($_GET["auth"] == 'signin') {
                                echo '<div class="page page-signin" style=display:block>';
                            } else {
                                echo '<div class="page page-signin" style=display:none>';
                            }
                            ?>
                            <div class="title panel__title text-center">
                            Authorization
                            </div>
                            <div class="panel__subtitle text-center mt-12">
                            Welcome to <php echo $sitename?>!
                            </div>
                            <form class="panel__form" id="sign">
                                <input class="input auth__input mb-10" name="login" type="text" placeholder="Enter the login" required>
                                <input class="input auth__input" name="password" type="password" placeholder="Enter the password" required>
                                <button class="btn btn_type_button btn_background_blue wd-full text-center mt-20">Authorization</button>
                            </form>
                        </div>
                        <?php
                        if ($_GET["auth"] == 'signup') {
                            echo '<div class="page page-signup" style=display:block>';
                        } else {
                            echo '<div class="page page-signup" style=display:none>';
                        }
                        ?>
                        <div class="title panel__title text-center">
                        Registration
                        </div>
                        <div class="panel__subtitle text-center mt-12">
                        Welcome to <php echo $sitename?>!
                        </div>
                        <form class="panel__form" id="req_form">
                            <input class="input auth__input mb-10" name="login" type="text" placeholder="Enter the login" required>
                            <input class="input auth__input mb-10" name="email" type="email" placeholder="Enter your E-mail" required>
                            <div class="input__wrapper mb-10">
                                <input class="input auth__input" name="password" type="password" placeholder="Enter the password" required>
                                <a class="input__btn" href="#">
                                    Show
                                </a>
                            </div>
                            <div class="input__wrapper mb-10">
                                <input class="input auth__input" name="rep_pass" type="password" placeholder="Repeat the new password" required>
                                <a class="input__btn" href="#">
                                    Show
                                </a>
                            </div>
                            <button type="submit" class="btn btn_type_button btn_background_blue wd-full text-center mt-20">Registration</button>
                        </form>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="../js/libs/jquery-3.6.1.min.js"></script>
    <script src="../js/libs/wow.min.js"></script>
    <script>
        $('.header').addClass('header_background_white');
    </script>
    <script src="../js/script.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</body>

</html>