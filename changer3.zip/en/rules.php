<!DOCTYPE html>
<html lang="en">

<?php
include('../layout/en/head.php');
include('../vender/logic.php');
$block = check_ip();
if ($block == false) {
    header('Location: ' . 'en/error.php');
}
?>

<body>

    <div class="wrapper">
        <div class="preloader">
            <div class="preloader__loader"></div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/en/header_reg.php');
        } else {
            include('../layout/en/header.php');
        }
        ?>
        <main class="main">
            <section class="rules">
                <div class="container rules__container">
                    <div class="rules__start wow animate__fadeInLeft" data-wow-delay=".25s">
                        <h1 class="title rules__title">
                            Service rules
                        </h1>
                        <h2 class="title rules__subtitle">
                            Purpose and scope
                            <div>Rules of Service</div>
                        </h2>
                        <p class="rules__text">
                            1.1. These Rules for the provision of services by the service <?= $_SERVER['SERVER_NAME'] ?> (hereinafter -
                            Rules)
                            establish requirements and contain a description of:
                        </p>
                        <p class="rules__text">
                            1.1.1. Procedure for providing the multicurrency exchange service <?= $_SERVER['SERVER_NAME'] ?>
                        </p>
                        <p class="rules__text">
                            1.1.2. Public offer To users of the services of the service <?= $_SERVER['SERVER_NAME'] ?>
                        </p>
                        <p class="rules__text">
                            1.1.3. Separation of responsibility for the use and provision of services by the service
                            <?= $_SERVER['SERVER_NAME'] ?>
                        </p>
                        <p class="rules__text">
                            1.1.4. Measures to minimize the risk of money laundering and terrorist financing.
                        </p>
                        <p class="rules__text">
                            1.2. <?= $_SERVER['SERVER_NAME'] ?> or Service - a system that provides Users with the opportunity to exchange
                            crypto-currencies for electronic money and (or) national currency, as well as the exchange of electronic
                            of money
                            and (or) national currency for a cryptocurrency located and functioning on a website in the network
                            Internet at <?= $_SERVER['SERVER_NAME'] ?>
                        </p>
                        <p class="rules__text">
                            1.3. The service is located in the territory of the state of Belgium. According to the current
                            legislative regulation, in Belgium the activity on the civil circulation of cryptocurrency
                            normatively not
                        </p>
                    </div>
                    <div class="rules__end wow animate__fadeInRight" data-wow-delay=".25s">
                        <div class="panel rules__panel">
                            <div class="panel__top">
                                <h3 class="title rules__panel-title">
                                    Reviews
                                </h3>
                            </div>
                            <div class="panel__line rules__panel-line">
                                <div></div>
                            </div>
                            <div class="panel__bottom">
                                <div class="rules__panel-blocks">
                                    <?php
                                    $reviews = get_review_nums(1, 6);
                                    while ($review = $reviews->fetch_array()) {
                                        echo '<div class="reviews__block rules__panel-block">
                                    <div class="reviews__block-top">
                                        <img src="../img/icons/user.svg" alt="user">
                                        <div class="reviews__block-wrapper ml-20">
                                            <div class="reviews__block-username">
                                            ' . $review['name-en'] . '
                                            </div>
                                            <div class="reviews__block-date">
                                            ' . $review['data'] . '
                                            </div>
                                        </div>
                                    </div>
                                    <div class="reviews__block-bottom">
                                        <p class="reviews__block-text rules__panel-text">
                                        ' . $review['descriptions-en'] . '
                                        </p>
                                    </div>
                                </div>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <a class="btn btn_background_blue wd-full mt-20 text-center" href="/en/index.php#reviews">Read all reviews</a>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="../js/libs/jquery-3.6.1.min.js"></script>
    <script src="../js/libs/wow.min.js"></script>
    <script src="../js/script.js"></script>
</body>

</html>