<?php
include('../config.php');
$support_tg = support_tg;
?>
<footer class="footer">
    <div class="container footer__container">
        <nav class="nav footer__nav">
            <div class="nav__wrapper footer__wrapper">
                <a class="nav__logo footer__logo" href="/en/index.php">
                    <img src="../img/logo.svg" alt="logo">
                </a>
                <p class="nav__text">
                    We work 24 hours
                </p>
            </div>
            <div class="nav__wrapper footer__wrapper">
                <div class="nav__lang footer__lang">
                    <a class="nav__lang-link" href="/index.php">RU</a>
                    <a class="nav__lang-link nav__lang-link_active" href="/en/index.php">EN</a>
                </div>
                <ul class="nav__list footer__list">
                    <li class="nav__item">
                        <a class="nav__link" href="https://t.me/<?php echo $support_tg?>">Support</a>
                    </li>
                    <li class="nav__item">
                        <a class="nav__link" href="/en/rules.php">Rules</a>
                    </li>
                    <li class="nav__item">
                        <a class="nav__link" href="/en/partners.php">Partners</a>
                    </li>
                    <li class="nav__item">
                        <a class="nav__link" href="/en/index.php#reviews">Reviews</a>
                    </li>
                </ul>
                <div class="footer__btns">
                    <a class="btn btn_border_gray nav__btn" href="/en/account.php">
                        <?php
                        session_start();
                        echo $_SESSION['email'];
                        ?>
                        <a href="vender/logout.php">
                            <img src="../img/btn/exit.png" alt="exit">
                        </a>
                    </a>
                </div>
            </div>
        </nav>
    </div>
</footer>