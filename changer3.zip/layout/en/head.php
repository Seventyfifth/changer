<?php
include('../config.php');
$sitename = sitename;
?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $sitename?></title>
    <link rel="icon" href="/img/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="../css/libs/bootstrap-reboot.min.css">
    <link rel="stylesheet" href="../css/libs/fonts.css">
    <link rel="stylesheet" href="../css/libs/animate.min.css">
    <link rel="stylesheet" href="../css/style.min.css">
</head>
