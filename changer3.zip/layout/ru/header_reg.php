<?php
include('../config.php');
$support_tg = support_tg;
?>
<header class="header">
    <div class="container header__container">
        <nav class="nav">
            <div class="nav__wrapper header__wrapper">
                <a class="nav__logo" href="/ru/index.php">
                    <img src="../img/logo.svg" alt="logo">
                </a>
                <p class="nav__text">
                    Работаем 24 часа
                </p>
            </div>
            <div class="nav__wrapper header__menu">
                <div class="nav__lang header__lang">
                    <a class="nav__lang-link header__nav-lang-link nav__lang-link_active" href="/ru/index.php">RU</a>
                    <a class="nav__lang-link header__nav-lang-link" href="/en/index.php">EN</a>
                </div>
                <ul class="nav__list header__list">
                    <li class="nav__item header__item">
                        <a class="nav__link" href="https://t.me/<?php echo $support_tg?>">Поддержка</a>
                    </li>
                    <li class="nav__item header__item">
                        <a class="nav__link" href="/ru/rules.php">Правила</a>
                    </li>
                    <li class="nav__item header__item">
                        <a class="nav__link" href="/ru/partners.php">Партнёрам</a>
                    </li>
                    <li class="nav__item header__item">
                        <a class="nav__link" href="/ru/index.php#reviews">Отзывы</a>
                    </li>
                </ul>
                <a class="btn btn_border_gray nav__btn" href="/ru/account.php">
                    <?php
                    session_start();
                    echo $_SESSION['email'];
                    ?>
                    <a href="/ru/vender/logout.php">
                        <img src="../img/btn/exit.png" alt="exit">
                    </a>
                </a>
            </div>
            <div class="header__burger">
                <div class="header__burger-line"></div>
                <div class="header__burger-line"></div>
                <div class="header__burger-line"></div>
            </div>
        </nav>
    </div>
</header>