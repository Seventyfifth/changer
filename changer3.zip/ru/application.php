<!DOCTYPE html>
<html lang="ru">

<?php
include('../layout/ru/head.php');
include('../vender/logic.php');
$block = check_ip();
if ($block == false) {
    header('Location: ' . 'ru/error.php');
}
?>
<?php
// $name_from = str_replace(" ", '', $_GET['name_from']);;
// $sign_from = $_GET['sign_from'];
// $name_to = str_replace(" ", '', $_GET['name_to']);
// $sign_to = $_GET['sign_to'];
// $address = $_GET['address'];
// $summa_from = $_GET['summa_from'];
// $summa_to = $_GET['summa_to'];
// $coin_from = get_coin_by_name($name_from);
// $coin_to = get_coin_by_name($name_to);
// if(empty($name_from) or empty($sign_from) or empty($name_to) or empty($sign_to) or empty($address) or empty($summa_from) or empty($summa_to) or $coin_from == null or $coin_to == null){
//     header('Location: '.'index.php');
// }

// $kurs = json_decode(get_kurs($sign_from, $sign_to), true);
// $kurs_to = $kurs[$sign_to];
// $address_to = 'asdasd';
// $create_date = date("m.d.y H:i");
$exchange_id = $_GET['exchange_id'];
$exchange = get_exchange_id($exchange_id);
if ($exchange['ip'] != get_ip()) {
    header('Location: ' . 'ru/index.php');
}
$coin_from = get_coin_by_id($exchange['id_coin_from']);
$coin_to = get_coin_by_id($exchange['id_coin_to']);
?>

<body>

    <div class="wrapper">
        <div class="preloader">
            <div class="preloader__loader"></div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/ru/header_reg.php');
        } else {
            include('../layout/ru/header.php');
        }
        ?>
        <main class="main">
            <section class="application">
                <div class="container application__container">
                    <div class="application__start wow animate__fadeInLeft" data-wow-delat=".25s">
                        <h1 class="title application__title">
                            Заявка <span><?php
                                            echo $exchange['id'];
                                            ?></span>
                        </h1>
                        <h2 class="title application__subtitle">
                            Пара для обмена
                        </h2>
                        <div class="application__blocks">
                            <div class="application__block">
                                <?php
                                if ($coin_from['type'] == 'crypto') {
                                    echo '<img class="application__block-img" src="../img/coins/' . $coin_from['icon'] . '" alt="coin">';
                                } elseif ($coin_from['type'] == 'card') {
                                    echo '<img class="application__block-img" src="../img/banks/' . $coin_from['icon'] . '" alt="bank">';
                                }
                                ?>
                                <div class="application__block-wrapper">
                                    <div class="application__block-title">
                                        <?php
                                        echo $coin_from['name'];
                                        ?>
                                    </div>
                                    <div class="application__block-subtitle">
                                        <?php
                                        echo "{$exchange['summ_from']}";
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="application__block">
                                <?php
                                if ($coin_to['type'] == 'crypto') {
                                    echo '<img class="application__block-img" src="../img/coins/' . $coin_to['icon'] . '" alt="coin">';
                                } elseif ($coin_to['type'] == 'card') {
                                    echo '<img class="application__block-img" src="../img/banks/' . $coin_to['icon'] . '" alt="bank">';
                                }
                                ?>
                                <div class="application__block-wrapper">
                                    <div class="application__block-title">
                                        <?php
                                        echo $coin_to['name'];
                                        ?>
                                    </div>
                                    <div class="application__block-subtitle">
                                        <?php
                                        echo "{$exchange['summ_to']}";
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="application__block">
                                <img class="application__block-img" src="../img/icons/change.png" alt="change">
                                <div class="application__block-wrapper">
                                    <div class="application__block-title">
                                        Конечные реквизиты
                                    </div>
                                    <div class="application__block-subtitle">
                                        <?php
                                        echo $exchange['address'];
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="application__wrapper">
                            <div class="btn btn_background_blue application__fixed">Зафиксировано</div>
                            <div class="btn btn_border_gray application__time" id="small_ticket">30:00</div>
                        </div>
                        <h3 class="title application__title_small" id="fixed_kurs">
                            <?php
                            echo "Курс зафиксирован на 30 минут на значении {$exchange['kurs']} {$coin_to['sign']}";
                            ?>
                        </h3>
                        <p class="application__text" id="info_text">
                            Если в течение этого времени не будет получено 1-е подтверждение сети, то курс будет
                            зафиксирован в момент получения 1-го подтверждения. Обмен будет выполнен автоматически,
                            после 1-го подтверждения вашей транзакции в сети
                        </p>
                        <div class="application__payments">
                            <div class="application__payment">
                                <div class="step step_active application__payment-step">
                                    1
                                </div>
                                <div class="application__payment-wrapper">
                                    <div class="application__payment-title">
                                        Обработка платежа
                                    </div>
                                    <p class="application__payment-text wd-300">
                                        После того, как вы отправите свой платеж, наш робот автоматически увидит вашу
                                        транзакцию. Вам не нужно никуда нажимать или писать в поддержку
                                    </p>
                                </div>
                            </div>
                            <div class="application__payment">
                                <div class="step application__payment-step">
                                    2
                                </div>
                                <div class="application__payment-wrapper">
                                    <div class="application__payment-title application__payment-title_light">
                                        Перевод
                                    </div>
                                    <p class="application__payment-text application__payment-text_light wd-200">
                                        После того, как мы получим ваш платеж, наша система сразу же переведёт вам ваши
                                        средства
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="application__end wow animate__fadeInRight" data-wow-delat=".25s">
                        <div class="application__timer">
                            <div class="application__timer-border"></div>
                            <div class="application__timer-title">
                                Время
                            </div>
                            <div class="application__timer-time">
                                30:00
                            </div>
                        </div>
                        <div class="panel application__panel" id="exchange">
                            <div class="panel__top">
                                <h3 class="title application__panel-title">
                                    Отправьте сюда
                                </h3>
                            </div>
                            <div class="panel__line application__panel-line">
                                <div></div>
                            </div>
                            <div class="panel__bottom">
                                <div class="application__panel-block">
                                    <?php
                                    if ($coin_from['type'] == 'crypto') {
                                        echo '<img class="application__panel-block-img" src="../img/coins/' . $coin_from['icon'] . '" alt="coin">';
                                    } elseif ($coin_from['type'] == 'card') {
                                        echo '<img class="application__panel-block-img" src="../img/banks/' . $coin_from['icon'] . '" alt="bank">';
                                    }
                                    ?>
                                    <div class="application__panel-block-wrapper">
                                        <div class="application__panel-block-title">
                                            Вы отправляете
                                        </div>
                                        <div class="application__panel-block-subtitle">
                                            <?php
                                            echo $exchange['summ_from'] . ' ' . $coin_from['sign'];
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="application__block application__block-copy">
                                    <div class="application__block-wrapper">
                                        <div class="application__block-title">
                                            На наши реквизиты
                                        </div>
                                        <div class="application__block-subtitle">
                                            <?php
                                            echo $exchange['address_to'];
                                            ?>
                                        </div>
                                    </div>
                                    <input class="input" type="text" value="<?php
                                                                            echo $exchange['address_to'];
                                                                            ?>" style="display: none;">
                                    <a class="btn btn_background_blue application__btn input__copy" href="#">
                                        <img src="../img/icons/copy.png" alt="copy">
                                    </a>
                                </div>
                                <?php
                                if ($coin_from['type'] == 'crypto') {
                                    echo '<div class="application__panel-block">
                                            <img class="mr-24 application__qr" src="https://chart.googleapis.com/chart?chs=177x177&amp;cht=qr&amp;chl=' . $exchange['address_to'] . '&choe=UTF-8"
                                                alt="QR code">
                                            <div class="application__panel-block-wrapper">
                                                <div class="application__panel-block-subtitle">
                                                    QR-код для оплаты в приложении
                                                </div>
                                                <div class="application__panel-block-title mt-10">
                                                    Наведите камеру во время перевода из приложения
                                                </div>
                                            </div>
                                        </div>';
                                }
                                ?>

                                <div class="application__wrapper-info">
                                    <h3 class="title application__title_small">
                                        Уже оплатили?
                                    </h3>
                                    <p class="application__text">
                                        После проведения транзакции по нашим реквизитам нажмите на кнопку “Я оплатил” ниже.
                                        После этого начнётся процесс выполнения вашей заявки
                                    </p>
                                    <a class="btn btn_background_blue application__btn-payed mt-20" href="#">Я оплатил</a>
                                </div>
                            </div>
                        </div>
                        <div class="application__date">
                            <div class="application__date-img">
                                <img src="../img/icons/calendar.png" alt="calendar">
                            </div>
                            <div class="application__date-wrapper">
                                <div class="application__date-title">
                                    Дата создания заявки
                                </div>
                                <div class="application__date-subtitle">
                                    <?php
                                    echo $exchange['data'];
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="panel application__panel" id="done_exchange" style="min-height:0px;display:none;margin-top:20px;">
                            <div class="panel__top">
                                <h3 class="title application__panel-title">
                                    Перевод завершен
                                </h3>
                            </div>
                            <div class="panel__line application__panel-line">
                                <div></div>
                            </div>
                            <div class="panel__bottom">
                                <div class="application__wrapper-info">
                                    <h3 class="title application__title_small">
                                        Средства выплачены
                                    </h3>
                                    <p class="application__text">
                                        Спасибо, что воспользовались нашими услугами! 
                                        не забудьте оставить о нас отзыв. Будем ждать вас снова!
                                    </p>
                                    <a class="btn btn_background_blue mt-20" href="index.php">На главную</a>
                                </div>
                            </div>
                        </div>
                        <div class="panel application__panel" id="eror_exchange" style="min-height:0px;display:none;margin-top:20px;">
                            <div class="panel__top">
                                <h3 class="title application__panel-title">
                                    Ошибка в заявке
                                </h3>
                            </div>
                            <div class="panel__line application__panel-line">
                                <div></div>
                            </div>
                            <div class="panel__bottom">

                                <div class="application__wrapper-info">
                                    <h3 class="title application__title_small">
                                        Средства не выплачены
                                    </h3>
                                    <p class="application__text">
                                        Мы не смогли совершить этот перевод по причине какой-то
                                        ошибки. Попробуйте еще раз, или обратитесь в поддержку.
                                    </p>
                                    <a class="btn btn_background_blue mt-20" href="index.php">На главную</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <section class="attention">
                <div class="container attention__container">
                    <h3 class="title attention__title">
                        Внимание!
                    </h3>
                    <p class="attention__subtitle">
                        Обращаем ваше внимание на то, что сервис не принимает средства с высокорисковых источников.
                        Каждая входящая транзакция проходит проверку через независимый AML сервис. В случае если
                        транзакция имеет более 70% риска, такие платежи будут приостановлены. И после прохождения
                        верификации личности они будут вам возвращены за вычетом комиссии сети! Обмен таких средств
                        невозможен! Рекомендуем с целью ускорения прохождения транзакции, увеличить комиссию в системе
                        Bitcoin.
                    </p>
                    <input value="<?php
                                    echo $exchange['id']
                                    ?>" id="id_exchage" type="hidden">
                </div>
            </section>
        </main>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/ru/footer_reg.php');
        } else {
            include('../layout/ru/footer.php');
        }
        ?>
    </div>

    <script src="../js/libs/jquery-3.6.1.min.js"></script>
    <script src="../js/libs/wow.min.js"></script>
    <script src="../js/script.js"></script>
    <script>
        if (localStorage.getItem('i_payment:' + $('#id_exchage').val())) {
            $(".application__wrapper-info").slideToggle(1000);
            $(".step").removeClass("step_active");
            $(".application__payment-title").addClass(
                "application__payment-title_light"
            );
            $(".application__payment-text").addClass("application__payment-text_light");
            $(".application__payment:nth-child(2) .step").addClass("step_active");
            $(
                ".application__payment:nth-child(2) .application__payment-title"
            ).removeClass("application__payment-title_light");
            $(
                ".application__payment:nth-child(2) .application__payment-text"
            ).removeClass("application__payment-text_light");
        }
        var id_exchage = <?php
                            echo $exchange['id']
                            ?>

        var type = "<?php
                    echo $coin_from['type']
                    ?>"


        if (localStorage.getItem('order:' + id_exchage)) {
            var time = localStorage.getItem('order:' + id_exchage)
        } else {

            var time = 30 * 60
            localStorage.setItem('order:' + id_exchage, time);
        }

        var status = 'waiting'
        const check_exchange = setInterval(() => {
            if (status == 'waiting') {
                if (localStorage.getItem('i_payment:' + $('#id_exchage').val())) {
                    var payment = "pay";
                } else {
                    var payment = "not_pay";
                }
                $.ajax({
                    url: '/vender/check_exchange.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        'id': id_exchage,
                        'type': type,
                        'payment': payment
                    },
                    success(data) {
                        if (data.status == 'waiting' || data.status == 'check') {
                            //pass
                        } else if (data.status == 'confirming') {
                            clearInterval(ticket);
                        } else if (data.status == 'done') {
                            change_();
                            $('#exchange').css("display", "none");
                            $('#done_exchange').css("display", "block");
                            $(".application__wrapper-info").css("display", "block");
                            status = data.status
                        } else {
                            change_();
                            $('#exchange').css("display", "none");
                            $('#eror_exchange').css("display", "block");
                            $(".application__wrapper-info").css("display", "block");
                            status = data.status
                        }
                    }
                })
            }
        }, 1000);

        function change_() {
            $('.application__wrapper').css("display", "none");
            $('.application__timer').css("display", "none");
            $('#fixed_kurs').css("display", "none");
            $('#info_text').css("display", "none");
            $('.application__payments').css("display", "none");
        }

        const ticket = setInterval(() => {
            time--;
            const minutes = Math.floor(time / 60);
            const seconds = time - minutes * 60;
            $('.application__timer-time').text(`${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);
            $('#small_ticket').text(`${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);
            localStorage.setItem('order:' + id_exchage, time);
            if (time == 0) {
                clearInterval(ticket)
                localStorage.removeItem('order:' + id_exchage);
                $.ajax({
                    url: '/vender/close_exchange.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        'id': id_exchage
                    }
                })
            }


        }, 1000);
    </script>
</body>

</html>