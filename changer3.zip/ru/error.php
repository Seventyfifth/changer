<!DOCTYPE html>
<html lang="ru">

<?php
include('../layout/ru/head.php');
include('../vender/logic.php');
$block = check_ip();
if ($block == false) {
    header('Location: ' . 'error.php');
}
?>

<body>

    <div class="wrapper">
        <div class="preloader">
            <div class="preloader__loader"></div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/ru/header_reg.php');
        } else {
            header('Location: ' . 'ru/index.php');
        }
        ?>
        <main class="main">
            <section class="error">
                <div class="container error__container">
                    <div class="error__face wow animate__fadeInUp">
                        <img src="../img/error/face.png" alt="face">
                    </div>
                    <h1 class="title error__title wow animate__fadeInUp" data-wow-delay=".25s">
                        404
                    </h1>
                    <h2 class="error__subtitle wow animate__fadeInUp" data-wow-delay=".5s">
                        Возникла ошибка со страницей. Возможно, этой страницы не существует. Вернитесь на Главную
                    </h2>
                    <a class="btn btn_background_blue error__btn wow animate__fadeInUp" data-wow-delay=".75s" href="/index.php">На главную</a>
                    <div class="error__shapes wow animate__fadeIn" data-wow-delay=".75s">
                        <img class="error__shape error__shape_1" src="../img/shapes-tg/2.png" alt="shape">
                        <img class="error__shape error__shape_2" src="../img/shapes-tg/3.png" alt="shape">
                        <img class="error__shape error__shape_3" src="../img/shapes-tg/4.png" alt="shape">
                        <img class="error__shape error__shape_4" src="../img/shapes-tg/5.png" alt="shape">
                        <img class="error__shape error__shape_5" src="../img/shapes-tg/4.png" alt="shape">
                        <img class="error__shape error__shape_6" src="../img/shapes-tg/6.png" alt="shape">
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="../js/libs/jquery-3.6.1.min.js"></script>
    <script src="../js/libs/wow.min.js"></script>
    <script src="../js/script.js"></script>
</body>

</html>