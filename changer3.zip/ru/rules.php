<!DOCTYPE html>
<html lang="ru">

<?php
include('../layout/ru/head.php');
include('../vender/logic.php');
$block = check_ip();
if ($block == false) {
    header('Location: ' . 'ru/error.php');
}
?>

<body>

    <div class="wrapper">
        <div class="preloader">
            <div class="preloader__loader"></div>
        </div>
        <?php
        session_start();
        if (isset($_SESSION['email'])) {
            include('../layout/ru/header_reg.php');
        } else {
            include('../layout/ru/header.php');
        }
        ?>
        <main class="main">
            <section class="rules">
                <div class="container rules__container">
                    <div class="rules__start wow animate__fadeInLeft" data-wow-delay=".25s">
                        <h1 class="title rules__title">
                            Правила сервиса
                        </h1>
                        <h2 class="title rules__subtitle">
                            Назначение и область применения
                            <div>Правил предоставлении услуг</div>
                        </h2>
                        <p class="rules__text">
                            1.1. Настоящие Правила предоставления услуг сервисом <?= $_SERVER['SERVER_NAME'] ?> (далее по тексту –
                            Правила)
                            устанавливают требования и содержат описание:
                        </p>
                        <p class="rules__text">
                            1.1.1. Порядка предоставления услуги мультивалютного обменного сервиса <?= $_SERVER['SERVER_NAME'] ?>
                        </p>
                        <p class="rules__text">
                            1.1.2. Публичной оферты Пользователям услуг сервиса <?= $_SERVER['SERVER_NAME'] ?>
                        </p>
                        <p class="rules__text">
                            1.1.3. Разграничения ответственности за использование и предоставление услуг сервисом
                            <?= $_SERVER['SERVER_NAME'] ?>
                        </p>
                        <p class="rules__text">
                            1.1.4. Мер по минимизации риска отмывания денежных средств и финансирования терроризма.
                        </p>
                        <p class="rules__text">
                            1.2. <?= $_SERVER['SERVER_NAME'] ?> или Сервис – система, предоставляющая Пользователям возможность обмена
                            криптовалюты на электронные деньги и (или) национальную валюту, а также обмен электронных
                            денег
                            и (или) национальной валюты на криптовалюту, расположенная и функционирующая на сайте в сети
                            Интернет по адресу <?= $_SERVER['SERVER_NAME'] ?>
                        </p>
                        <p class="rules__text">
                            1.3. Сервис размещается на территории государства Бельгия. В соответствии с текущим
                            законодательным регулированием, в Бельгии деятельность по гражданскому обороту криптовалюты
                            нормативно не урегулирован.
                        </p>
                    </div>
                    <div class="rules__end wow animate__fadeInRight" data-wow-delay=".25s">
                        <div class="panel rules__panel">
                            <div class="panel__top">
                                <h3 class="title rules__panel-title">
                                    Отзывы
                                </h3>
                            </div>
                            <div class="panel__line rules__panel-line">
                                <div></div>
                            </div>
                            <div class="panel__bottom">
                                <div class="rules__panel-blocks">
                                    <?php
                                    $reviews = get_review_nums(1, 6);
                                    while ($review = $reviews->fetch_array()) {
                                        echo '<div class="reviews__block rules__panel-block">
                                    <div class="reviews__block-top">
                                        <img src="../img/icons/user.svg" alt="user">
                                        <div class="reviews__block-wrapper ml-20">
                                            <div class="reviews__block-username">
                                            ' . $review['name-ru'] . '
                                            </div>
                                            <div class="reviews__block-date">
                                            ' . $review['data'] . '
                                            </div>
                                        </div>
                                    </div>
                                    <div class="reviews__block-bottom">
                                        <p class="reviews__block-text rules__panel-text">
                                        ' . $review['descriptions-ru'] . '
                                        </p>
                                    </div>
                                </div>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <a class="btn btn_background_blue wd-full mt-20 text-center" href="/ru/index.php#reviews">Читать все отзывы</a>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script src="../js/libs/jquery-3.6.1.min.js"></script>
    <script src="../js/libs/wow.min.js"></script>
    <script src="../js/script.js"></script>
</body>

</html>