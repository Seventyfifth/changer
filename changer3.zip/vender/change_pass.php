<?php
include('logic.php');

$pass = $_POST['pass'];
$req_pass = $_POST['req_pass'];
$lang = $_POST['lang'];
if($pass != $req_pass){
    if($lang == 'ru'){
        echo json_encode(['status' => 400, 'message' => 'Пароли не совпадают']);
    }else{
        echo json_encode(['status' => 400, 'message' => 'Passwords do not match']);
    }
    
}else{
    session_start();
    if(isset($_SESSION['email'])){
        change_password($_SESSION['email'], $pass);
        if($lang == 'ru'){
            echo json_encode(['status' => 200, 'message' => 'Пароль изменин']);
        }else{
            echo json_encode(['status' => 200, 'message' => 'Password changed']);
        }
        
    }
}


?>