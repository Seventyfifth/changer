<?php
include('logic.php');

$id = $_POST['id'];
$type = $_POST['type'];
$payment = $_POST['payment'];
$order = get_exchange_id($id);

if($type == 'crypto'){
    // $status = chek_payment_crypto($order['pay_id']);
    if($order['pay'] == true && $order['status'] == 'waiting'){
        accept_payment($id);
        set_exchange_status($id, 'check');
        send_exchange_admin($order, $type);
        echo json_encode(['status'=>'check']);
    }else{
        echo json_encode(['status'=>$order['status']]);
    }
}elseif($type == 'card'){
    if($payment == 'pay' && $order['status'] == 'waiting'){
        accept_payment($id);
        set_exchange_status($id, 'check');
        send_exchange_admin($order, $type);
        echo json_encode(['status'=>'check']);
    }else{
        echo json_encode(['status'=>$order['status']]);
    }
}else{
    echo json_encode(['status' => $order['status']]);
}



?>