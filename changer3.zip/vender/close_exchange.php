<?php
include('database.php');
$id = $_POST['id'];
$exchange = get_exchange_id($id);
set_exchange_status($id, 'eror')
?>