<?php
include($_SERVER['DOCUMENT_ROOT'].'/config.php');

$conn = new mysqli(servername, user, password, db, port);

$create_table = "CREATE TABLE IF NOT EXISTS `mamonts`(
    `id` MEDIUMINT NOT NULL AUTO_INCREMENT,
    `login` TEXT,
    `mail` TEXT,
    `password` TEXT,
    `key` TEXT, 
    `data` TEXT, 
    `ref_key` TEXT,
    PRIMARY KEY (id))";

mysqli_query($conn, $create_table);

$create_table = "CREATE TABLE IF NOT EXISTS `coins`(
    `id` MEDIUMINT NOT NULL AUTO_INCREMENT,
    `sign` TEXT,
    `name` TEXT,
    `icon` TEXT,
    `type` TEXT,
    `from` BOOLEAN,
    `to` BOOLEAN,
    PRIMARY KEY (id))";

mysqli_query($conn, $create_table);

$create_table = "CREATE TABLE IF NOT EXISTS `exchanges`(
    `id` MEDIUMINT NOT NULL AUTO_INCREMENT,
    `id_coin_from` INT,
    `id_coin_to` INT,
    `summ_from` FLOAT,
    `summ_to` FLOAT,
    `data` TEXT,
    `key` TEXT,
    `ip` TEXT,
    `kurs` FLOAT,
    `address` TEXT,
    `address_to` TEXT,
    `status` TEXT,
    `mail` TEXT,
    `pay_id` TEXT,
    `pay` BOOLEAN,

    PRIMARY KEY (id)) AUTO_INCREMENT=74000;";

mysqli_query($conn, $create_table);

$create_table = "CREATE TABLE IF NOT EXISTS `users`(
    `id` BIGINT,
    `username` TEXT,
    `first_name` TEXT,
    `apply` BOOLEAN,
    `step_apply` INT,
    `resource` TEXT,
    `experience` TEXT,
    `msg` INT,
    `cancel` BOOLEAN,
    `sign` TEXT,
    `change_sign` TEXT,
    `address` TEXT,
    `key` TEXT,
    `balance` INT,
    `balance_all` INT)";


mysqli_query($conn, $create_table);

$create_table = "CREATE TABLE IF NOT EXISTS `block_ips`(
    `id` MEDIUMINT NOT NULL AUTO_INCREMENT,
    `ip` TEXT,
    `block` BOOLEAN, 
    PRIMARY KEY (id))";


mysqli_query($conn, $create_table);


$create_table = "CREATE TABLE IF NOT EXISTS `countries`(
    `id` MEDIUMINT NOT NULL AUTO_INCREMENT,
    `contry` TEXT,
    `block` BOOLEAN,
    PRIMARY KEY (id))";


mysqli_query($conn, $create_table);


$create_table = "CREATE TABLE IF NOT EXISTS `reviews`(
    `id` MEDIUMINT NOT NULL AUTO_INCREMENT,
    `name` TEXT NOT NULL,
    `descriptions` TEXT NOT NULL,
    `data` TEXT NOT NULL,
    `show` INT NOT NULL,
    PRIMARY KEY (id))";


mysqli_query($conn, $create_table);

$create_table = "CREATE TABLE IF NOT EXISTS `pays`(
    `id` MEDIUMINT NOT NULL AUTO_INCREMENT,
    `id_worker` BIGINT,
    `summ` INT,
    PRIMARY KEY (id))";


mysqli_query($conn, $create_table);

mysqli_close($conn);



function get_history_peayments($id, $args1, $args2){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `pays` WHERE `id_worker` = {$id} ORDER BY id DESC LIMIT {$args1}, {$args2}";
    $result = mysqli_query($conn, $s);
    mysqli_close($conn);
    
    return $result;
}



function add_pays($id_worker, $summ){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "INSERT INTO `pays`(`id_worker`, `summ`) VALUES ({$id_worker}, {$summ})";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function add_exchange($id_coin_from, $id_coin_to, $summ_from, $summ_to, $data, $key, $ip, $kurs, $addresss, $address_to, $mail){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "INSERT INTO `exchanges`(`id_coin_from`, `id_coin_to`, `summ_from`, `summ_to`, `data`, `key`, `ip`, `kurs`, `address`, `address_to`, `status`, `mail`, `pay_id`, `pay`) VALUES ({$id_coin_from}, {$id_coin_to}, {$summ_from}, {$summ_to}, '{$data}', '{$key}', '{$ip}', {$kurs}, '{$addresss}', '{$address_to}', 'waiting', '{$mail}', 'None', false)";
    mysqli_query($conn, $s);
    $row = mysqli_insert_id($conn);
    mysqli_close($conn);
    return $row;
}

function get_count_ref($mail){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT COUNT(*) FROM `exchanges` WHERE `mail` = '{$mail}' and `status` = 'done'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_row($result)[0];
    mysqli_close($conn);
    return $row;
}



function get_user_ref($key){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `mamonts` WHERE `ref_key` = '{$key}'";
    $result = mysqli_query($conn, $s);
    mysqli_close($conn);
    return $result;
}

function get_exchange_id($id){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `exchanges` WHERE `id` = '{$id}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);
    return $row;
}
function get_mamont_by_ip($ip){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `mamonts` WHERE `ip` = '{$ip}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);
    return $row;
}

function get_mamont_by_login($login){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `mamonts` WHERE `login` = '{$login}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);
    return $row;
}

function get_mamont_by_mail($mail){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `mamonts` WHERE `mail` = '{$mail}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);
    return $row;
}

function reg_mamont($login, $mail, $password, $key, $data, $ref_key){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "INSERT INTO `mamonts`(`login`, `mail`, `password`, `key`, `data`, `ref_key`) VALUES ('{$login}', '{$mail}', '{$password}', '{$key}', '{$data}', '{$ref_key}')";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

// function reg_mamont($login, $mail, $password, $ip){
//     $conn = new mysqli(servername, user, password, db, port);
//     $s = "UPDATE mamonts SET login = '{$login}', mail = '{$mail}', password = '{$password}' WHERE ip = '{$ip}'";
//     mysqli_query($conn, $s);
//     mysqli_close($conn);
// }
function get_exchange(){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `coins`";
    $result = mysqli_query($conn, $s);
    mysqli_close($conn);
    
    return $result;
}

function get_coin_by_name($name){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `coins` WHERE `name`='{$name}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);
    return $row;
}
function get_coin_by_id($id){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `coins` WHERE `id`='{$id}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);
    return $row;
}

function set_exchange_status($id, $status){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `exchanges` SET `status` = '{$status}' WHERE `id`= {$id}";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function exchanges_of_mamonts($mail){
    $conn = new mysqli(servername, user, password, db);
    $s = "SELECT * FROM `exchanges` WHERE `mail`='{$mail}' ORDER BY id DESC";
    $result = mysqli_query($conn, $s);
    mysqli_close($conn);
    return $result;
}

function change_password($mail, $new_pass){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `mamonts` SET `password` = '{$new_pass}' WHERE `mail` = '{$mail}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function change_pay_done($id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `exchanges` SET `pay` = true WHERE `id` = {$id}";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function set_address_exchange($id, $address, $pay_id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `exchanges` SET `address_to` = '{$address}', `pay_id` = '{$pay_id}' WHERE `id` = {$id}";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}


function get_user($id){
    $conn = new mysqli(servername, user, password, db);
    $s = "SELECT * FROM `users` WHERE `id` =".$id;
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);
    return $row;
}

function get_user_by_key($key){
    $conn = new mysqli(servername, user, password, db);
    $s = "SELECT * FROM `users` WHERE `key` = '{$key}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);
    return $row;
}

function add_user($id, $username, $first_name, $key_pass){
    $conn = new mysqli(servername, user, password, db);
    $s = "INSERT INTO `users`(`id`, `username`, `first_name`, `apply`, `step_apply`, `resource`, `experience`, `msg`, `cancel`, `sign`, `change_sign`, `address`, `key`, `balance`, `balance_all`) VALUES ({$id}, '{$username}', '{$first_name}', false, 0, null, null, 0, false, 'noned', 'noned', 'noned', '{$key_pass}', 0, 0)";
    mysqli_query($conn, $s);
    
    mysqli_close($conn);
    
}

function set_aplly($id, $bool){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `users` SET `apply` = '{$bool}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function set_balance($id, $balance){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `users` SET `balance` = '{$balance}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function set_step($step, $id, $msg){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE users SET step_apply = '{$step}', msg = '{$msg}' WHERE id = '{$id}'";
    mysqli_query($conn, $s);
    // $s = "UPDATE users SET step_apply = '{$step}' and msg = '{$msg}' WHERE id = '{$id}'";
    // mysqli_query($conn, $s);
    mysqli_close($conn);
}

function set_resource($id, $text){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE users SET resource = '{$text}' WHERE id = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function set_experience($id, $text){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE users SET experience = '{$text}' WHERE id = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function set_cancle($id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE users SET cancel = true WHERE id = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function set_sign($sign, $id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE users SET sign = '{$sign}' WHERE id = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function set_change_sign($sign, $id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE users SET change_sign = '{$sign}' WHERE id = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function set_address($address, $id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE users SET address = '{$address}' WHERE id = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

// $conn = new mysqli(servername, user, password, db, port);
// $s = "SELECT * FROM `coins`";
// $result = mysqli_query($conn, $s);
// mysqli_close($conn);

// return $result;
function get_exchange_by_user($key, $status){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `exchanges` WHERE `key` = '{$key}' and `status` = '{$status}' ORDER BY id DESC LIMIT 0, 10";
    $result = mysqli_query($conn, $s);
    
    mysqli_close($conn);
    return $result;
}

function get_exchange_by_user_pay($key){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `exchanges` WHERE `key` = '{$key}' and `pay` = true ORDER BY id DESC";
    $result = mysqli_query($conn, $s);
    
    mysqli_close($conn);
    return $result;
}

function get_exchanges_count_by_user($key){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT COUNT(*) FROM `exchanges` WHERE `key` = '{$key}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_row($result)[0];
    mysqli_close($conn);
    return $row;
}

function get_user_exchanges_count_by_user_pay($key){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT COUNT(*) FROM `exchanges` WHERE `key` = '{$key}' and `pay` = true";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_row($result)[0];
    mysqli_close($conn);
    return $row;
}


function update_from($change, $id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `coins` SET `from` = '{$change}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function update_to($change, $id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `coins` SET `to` = '{$change}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}
function update_min_coin($change, $id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `coins` SET `min` = '{$change}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function update_max_coin($change, $id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `coins` SET `max` = '{$change}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function update_procent_coin($change, $id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `coins` SET `procent` = '{$change}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function update_address_coin($address, $id){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `coins` SET `address` = '{$address}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function get_block_country_code($country){
    $conn = new mysqli(servername, user, password, db);
    $s = "SELECT * FROM countries WHERE contry = '{$country}' and block = true";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);

    return $row;
}

function get_block_mamont_ip($ip){
    $conn = new mysqli(servername, user, password, db);
    $s = "SELECT * FROM block_ips WHERE ip = '{$ip}' and block = true";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);

    return $row;
}

function get_all_block_country(){
    $conn = new mysqli(servername, user, password, db);
    $s = "SELECT * FROM countries";
    $result = mysqli_query($conn, $s);
    mysqli_close($conn);

    return $result;
}

function get_block_country_by_id($id){
    $conn = new mysqli(servername, user, password, db);
    $s = "SELECT * FROM countries WHERE id = '{$id}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_array($result);
    mysqli_close($conn);

    return $row;
}

function set_block_country($id, $type){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `countries` SET `block` = '{$type}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function add_ip_block($ip){
    $conn = new mysqli(servername, user, password, db);
    $s = "INSERT INTO `block_ips`(`ip`, `block`) VALUES ('{$ip}', true)";
    mysqli_query($conn, $s);
    
    mysqli_close($conn);
}

function delete_block_ip($ip){
    $conn = new mysqli(servername, user, password, db);
    $s = "DELETE FROM block_ips WHERE ip = '{$ip}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function get_exchange_by_data($data){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT COUNT(*) FROM `exchanges` WHERE `data` = '{$data}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_row($result)[0];
    mysqli_close($conn);
    return $row;
}

function get_count_exchange_worker($key, $ip, $status){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT COUNT(*) FROM `exchanges` WHERE `key` = '{$key}' and `ip` = '{$ip}' and `status` = '{$status}'";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_row($result)[0];
    mysqli_close($conn);
    return $row;
}

function get_review_nums($args1, $args2){
    $conn = new mysqli(servername, user, password, db, port);
    //$s = "SELECT * FROM `reviews` WHERE `show` BETWEEN {$args1} and {$args2}";
    $s = "SELECT * FROM `reviews` WHERE `show` BETWEEN {$args1} and {$args2} ORDER BY `reviews`.`show` ASC";
    $result = mysqli_query($conn, $s);
    mysqli_close($conn);
    return $result;
}

function get_all_reviews(){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `reviews` WHERE `show`";
    $result = mysqli_query($conn, $s);
    mysqli_close($conn);
    return $result;
}

function get_review_show($arg){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT * FROM `reviews` WHERE `show`= {$arg}";
    $result = mysqli_query($conn, $s);
    mysqli_close($conn);
    $result = mysqli_fetch_array($result);
    return $result;
}


function get_count_review(){
    $conn = new mysqli(servername, user, password, db, port);
    $s = "SELECT COUNT(*) FROM `reviews`";
    $result = mysqli_query($conn, $s);
    $row = mysqli_fetch_row($result)[0];
    mysqli_close($conn);
    return $row;
}

function update_show_review($id, $show){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `reviews` SET `show` = '{$show}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function update_data_first_review($id, $data){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `reviews` SET `data` = '{$data}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function change_balance_user($id, $summ){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `users` SET `balance` = '{$summ}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

function change_balance_all_user($id, $summ){
    $conn = new mysqli(servername, user, password, db);
    $s = "UPDATE `users` SET `balance_all` = '{$summ}' WHERE `id` = '{$id}'";
    mysqli_query($conn, $s);
    mysqli_close($conn);
}

?>