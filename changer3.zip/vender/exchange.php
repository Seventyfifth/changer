<?php
    include('logic.php');
    if(check_exchange_block() == false){
        header('Location: '.'error.php');
    }
    $name_from = str_replace("\n", '', str_replace(" ", '', $_POST['name_from']));
    
    $sign_from = $_POST['sign_from'];
    $name_to = str_replace("\n", '', str_replace(" ", '', $_POST['name_to']));
    $sign_to = $_POST['sign_to'];
    $address = $_POST['address'];
    $summa_from = $_POST['summa_from'];
    $summa_to = $_POST['summa_to'];
    $create_date = date("m.d.y H:i");
    session_start();
    if(isset($_SESSION['key'])){
        $key = $_SESSION['key'];
        new_exchange_send_worker($key, $summa_from, $sign_from, $summa_to, $sign_to);
    }else{
        $key = 'None';
    }
    if(isset($_SESSION['email'])){
        $mail = $_SESSION['email'];
    }else{
        $mail = 'none';
    }
    


    $coin_from = get_coin_by_name($name_from);
    $coin_to = get_coin_by_name($name_to);
    if (empty($name_from) or empty($sign_from) or empty($name_to) or empty($sign_to) or empty($address) or empty($summa_from) or empty($summa_to) or $coin_from == null or $coin_to == null) {
        echo json_encode(['status'=>400]);
    }else {
        $ip = get_ip();
        $kurs = json_decode(get_kurs($sign_from, $sign_to), true);
        if($coin_to['procent'] == null){
            $file_admin = file_get_contents($_SERVER['DOCUMENT_ROOT']."/bot/admin.json");
            $json_a = json_decode($file_admin, true);
            $proc_to = $json_a['procent'];
        }else{
            $proc_to = $coin_to['procent'];
        }
        $kurs_to = round($kurs["estimated_amount"] * $proc_to, 6);
        
        $send_summ = round($kurs_to * $summa_from, 6);
        $address_to = '';
        if($coin_from['type'] == 'crypto'){
            $address_to = 'None';
        }elseif($coin_from['type'] == 'card'){
            if($coin_from['address'] == null){
                $address_to = get_defolt_address();
            }else{
                $address_to = $coin_from['address'];
            }
        }
        
        $id_exchange = add_exchange($coin_from['id'], $coin_to['id'], $summa_from, $send_summ, $create_date, $key, $ip, $kurs_to, $address, $address_to, $mail);
        if ($coin_from['type'] == 'crypto') {
            if($coin_from['sign'] == 'TRC20'){
                $currency = 'USDTTRC20';
            }elseif($coin_from['sign'] == 'ERC20'){
                $currency = 'USDTERC20';
            }else{
                $currency = $coin_from['sign'];
            }
            
            $address_to = json_decode(get_adddress_to_crypto($currency, $summa_from, $id_exchange), true);
            set_address_exchange($id_exchange, $address_to['pay_address'], $address_to['payment_id']);
        }
        echo json_encode(['status'=>200,'id' => $id_exchange]);
    }
