<?php
include('database.php');

$arg1 = $_POST['arg1'];
$arg2 = $_POST['arg2'];

$reviews = get_review_nums((int)$arg1, (int)$arg2);
$data = [];
while ($review = $reviews->fetch_array()) {
    $data = array_merge($data, [['nameRu' => $review['name-ru'], 'nameEn' => $review['name-en'], 'descriptionsRu' => $review['descriptions-ru'], 'descriptionsEn' => $review['descriptions-en'], 'data' => $review['data']]]);
}

echo json_encode($data);
?>