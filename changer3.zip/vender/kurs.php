<?php
include('logic.php');
$first = strtoupper($_POST['first']);
$second = strtoupper($_POST['second']);
$data = get_kurs($first, $second);
echo json_encode($data);
?>