
<?php
if (!isset($_SESSION)) { session_start(); }


include('logic.php');
$login = $_POST['login'];
$email = $_POST['email'];
$password = $_POST['password'];
$rep_pass = $_POST['rep_pass'];
$lang = $_POST['lang'];



if($password == $rep_pass){
    $mamont_login = get_mamont_by_login($login);
    if($mamont_login == null){
        $mamont_mail = get_mamont_by_mail($email);
        if($mamont_mail == null){
            $key = generation_key();
            $create_date = date("d.m.y");  
            if(isset($_SESSION['ref'])){
                $ref_key = $_SESSION['ref'];
            }else{
                $ref_key = 'None';
            }
            reg_mamont($login, $email, $password, $key, $create_date, $ref_key);
            $_SESSION['email'] = $email;
            if ($lang == 'ru') {
                $data = ['status' => 200, 'text' => 'Успешно зарегистрирован'];
            }else{
                $data = ['status' => 200, 'text' => 'Successfully registered'];
            }
            
        }else{
            if ($lang == 'ru') {
                $data = ['status' => 400, 'text' => 'Почта уже привязана'];
            }else{
                $data = ['status' => 400, 'text' => 'Mail already linked'];
            }
        }
    }else{
        if ($lang == 'ru') {
            $data = ['status' => 400, 'text' => 'Такой пользователь уже есть'];
        }else{
            $data = ['status' => 400, 'text' => 'This user already exists'];
        }
    }
}else{
    if ($lang == 'ru') {
        $data = ['status' => 400, 'text' => "Не совпадают пароли"];
    }else{
        $data = ['status' => 400, 'text' => "Passwords don't match"];
    }
}

echo json_encode($data);
?>