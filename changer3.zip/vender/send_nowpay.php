<?php
include('logic.php');
$data = json_decode(file_get_contents('php://input'), TRUE);
$order_id = $data['order_id'];
$payment_status = $data['payment_status'];
if($payment_status == 'finished'){
    change_pay_done($order_id);
}elseif($payment_status == 'partially_paid'){
    change_pay_done($order_id);
}
?>