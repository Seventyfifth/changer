<?php
if (!isset($_SESSION)) { session_start(); }


include('logic.php');
$login = $_POST['login'];
$password = $_POST['password'];
$lang = $_POST['lang'];
$mamont_login = get_mamont_by_login($login);
if($mamont_login == null){
    $mamont_login = get_mamont_by_mail($login);
}
if($mamont_login != null){
    if($mamont_login['password'] == $password){
        $_SESSION['email'] = $mamont_login['mail'];
        if ($lang == 'ru') {
            $data = ['status' => 200, 'text' => 'Успешно зарегистрирован'];
        }else{
            $data = ['status' => 200, 'text' => 'Successfully registered'];
        }
    }else{
        if ($lang == 'ru') {
            $data = ['status' => 400, 'text' => 'Неверный пароль'];
        }else{
            $data = ['status' => 400, 'text' => 'Invalid password'];
        }
        
    }
}else{
    if ($lang == 'ru') {
        $data = ['status' => 400, 'text' => 'Пользователя с этим логином нет'];
    }else{
        $data = ['status' => 400, 'text' => 'There is no user with this login'];
    }
    
}

echo json_encode($data);
?>